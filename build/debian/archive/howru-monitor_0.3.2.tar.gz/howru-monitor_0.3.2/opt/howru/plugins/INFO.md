This is a spot where to symlink all your Nagios plugins
