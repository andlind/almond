static void add_plugin_status_metadata_json(struct json_object *object, const PluginItem *item) {
	struct json_object *history = json_object_new_array();
	for (size_t i = 0; i < item->historyCount; ++i) {
		struct json_object *entry = json_object_new_object();
		json_object_object_add(entry, "state",
							   json_object_new_string(plugin_status_name_json(
								   item->history[i].statusCode)));
		json_object_object_add(entry, "timestamp",
							   json_object_new_string(item->history[i].timestamp));
		json_object_array_add(history, entry);
	}
	json_object_object_add(object, "previousStatus",
						   json_object_new_string(plugin_status_name_json(
							   item->output.prevRetCode)));
	json_object_object_add(object, "statusChanged",
						   json_object_new_boolean(item->statusChanged[0] == '1'));
	json_object_object_add(object, "statusChangedAt",
						   json_object_new_string(item->statusChangedAt));
	json_object_object_add(object, "statusDuration",
						   json_object_new_int64(item->statusDuration));
	json_object_object_add(object, "history", history);
}
	add_plugin_status_metadata_json(plugin_obj, g_plugins[i]);
	json_object_object_add(plugin_obj, "maintenance", safe_json_string(g_plugins[i]->active > 0 ? "false" : "true"));
        json_object_object_add(plugin_obj, "lastChange", safe_json_string(g_plugins[i]->lastChangeTimestamp));
        json_object_object_add(plugin_obj, "lastRun", safe_json_string(g_plugins[i]->lastRunTimestamp));
        json_object_object_add(plugin_obj, "nextRun", safe_json_string(g_plugins[i]->nextRunTimestamp));
        if (enableCollector) {
		if (collector_metadata) {
			struct json_object *labels = get_labels_by_id(i);
			if (labels) {
				json_object_get(labels);
				json_object_object_add(plugin_obj, "labels", labels);
			}
		}
		if (collector_metrics && g_plugins[i]->output.retString != NULL) {
			struct json_object *perf = parse_perfdata(g_plugins[i]->output.retString);
                	if (perf) {
                        	json_object_object_add(plugin_obj, "metrics", perf);
                	}
		}
	}
        json_object_array_add(monitoring_array, plugin_obj);
    }

    // Write JSON to temp file
    bool json_ok = true;
    const char *json =
    json_object_to_json_string_ext(
        root,
        JSON_C_TO_STRING_PRETTY | JSON_C_TO_STRING_NOSLASHESCAPE
    );
    // Write JSON to the temp file
    if (fputs(json, tf) < 0) {
        writeLog("Failed to write JSON to temp file", 2, 0);
        json_ok = false;
    }
    // Free the JSON object
    json_object_put(root);
    /* close FILE* (this also closes the underlying fd) */
    if (fclose(tf) != 0) {
        writeLog("fclose failed on temp file", 2, 0);
        unlink(tmpname);
        pthread_mutex_unlock(&update_mtx);
        return;
    }
    tf = NULL;

    /* atomically replace target with temp file */
    if (json_ok) {
        if (rename(tmpname, targetname) != 0) {
            snprintf(infostr, infostr_size, "[Collect data] Rename failed: %s", strerror(errno));
            writeLog(trim(infostr), 2, 0);
            unlink(tmpname);
            pthread_mutex_unlock(&update_mtx);
            return;
        }
    }
    else {
        unlink(tmpname);
    	pthread_mutex_unlock(&update_mtx);
    	return;
    }
    t = clock() - t;
    snprintf(infostr, infostr_size, "Data collection took %.0f miliseconds to execute.", (double)t);
    writeLog(trim(infostr), 0, 0);

    pthread_mutex_unlock(&update_mtx);
}
	add_plugin_status_metadata_json(j_data, g_plugins[storeIndex]);
    	json_object_object_add(j_data, "pluginStatusCode", json_object_new_int(g_plugins[storeIndex]->output.retCode));

	/*if (enableCollector) {
		printf("DEBUG: Collector enabled\n");
		if (collector_metadata) {
			printf("DEBUG: collector_metadata enabled\n");
                        struct json_object *labels = get_labels_by_id(storeIndex);
                        if (labels) {
                                json_object_get(labels);
                                json_object_object_add(j_data, "labels", labels);
                        }
                }
                if (collector_metrics) {
			printf("DEBUG: collector_metrics enabled\n");
                        struct json_object *perf = parse_perfdata(g_plugins[storeIndex]->output.retString);
                        if (perf) {
                                json_object_object_add(j_data, "metrics", perf);
                        }

             	}
	}*/

	struct json_object *j_root = json_object_new_object();
    	json_object_object_add(j_root, "name", json_object_new_string(hostName));
        /*int count_bytes = strlen(hostName) + strlen(g_plugins[storeIndex]->lastChangeTimestamp) + strlen(g_plugins[storeIndex]->lastRunTimestamp) + strlen(g_plugins[storeIndex]->name) + strlen(g_plugins[storeIndex]->nextRunTimestamp);
        count_bytes += pluginitemdesc_size + pluginoutput_size;
        count_bytes += strlen(pluginStatus) + strlen(g_plugins[storeIndex]->statusChanged);
        count_bytes += 185;*/
        int kafka_export_addons = 0;
        if (enableKafkaTag) {
        	//count_bytes += strlen(kafka_tag);
        	//count_bytes += 12; // {"tag":""}
        	kafka_export_addons += 10;
        }
        if (enableKafkaId) {
        	//count_bytes += 9; // {"id":""}
        	//int length = snprintf(NULL, 0, "%d", kafka_start_id);
        	//count_bytes += length;
        	kafka_export_addons += 20;
        }
	/*payload = malloc((size_t)count_bytes);
        if (payload == NULL) {
        	fprintf(stderr, "Could not allocate memory for payload.\n");
        	writeLog("Failed to allocate memory [runPlugin:enableKafkaExport:payload]", 2, 0);
        	return;
        }*/
        if (kafka_export_addons < 1) {
        	/*sprintf(payload, "{\"name\":\"%s\", \"data\": {\"lastChange\":\"%s\", \"lastRun\":\"%s\", \"name\":\"%s\", \"nextRun\":\"%s\", \"pluginName\":\"%s\", \"pluginOutput\":\"%s\", \"pluginStatus\":\"%s\", \"pluginStatusChanged\":\"%s\", \"pluginStatusCode\":\"%d\"}}", hostName, g_plugins[storeIndex]->lastChangeTimestamp, currTime, pluginName, g_plugins[storeIndex]->nextRunTimestamp, g_plugins[storeIndex]->description, g_plugins[storeIndex]->output.retString, pluginStatus, g_plugins[storeIndex]->statusChanged, g_plugins[storeIndex]->output.retCode);
        	printf("Payload = %s\n", payload);*/
		printf("No add ons\n");
        }
        else {
       		/*if (kafka_export_addons == KAFKA_EXPORT_TAG) {
        		sprintf(payload, "{\"name\":\"%s\", \"tag\":\"%s\", \"data\": {\"lastChange\":\"%s\", \"lastRun\":\"%s\", \"name\":\"%s\", \"nextRun\":\"%s\", \"pluginName\":\"%s\", \"pluginOutput\":\"%s\", \"pluginStatus\":\"%s\", \"pluginStatusChanged\":\"%s\", \"pluginStatusCode\":\"%d\"}}", hostName, kafka_tag, g_plugins[storeIndex]->lastChangeTimestamp, currTime, pluginName, g_plugins[storeIndex]->nextRunTimestamp, g_plugins[storeIndex]->description, g_plugins[storeIndex]->output.retString, pluginStatus, g_plugins[storeIndex]->statusChanged, g_plugins[storeIndex]->output.retCode);
			json_object_object_add(j_root, "tag", json_object_new_string(kafka_tag));
        	}
        	else {
        		int nKafkaId = kafka_start_id + storeIndex;
        		int length = snprintf(NULL, 0, "%d", nKafkaId);
        		char* kafka_id = malloc((size_t)length + 1);
        		snprintf(kafka_id, (size_t)length+1, "%d", nKafkaId);
        		if (kafka_export_addons == KAFKA_EXPORT_ID) {
        			sprintf(payload, "{\"name\":\"%s\", \"id\":\"%s\", \"data\": {\"lastChange\":\"%s\", \"lastRun\":\"%s\", \"name\":\"%s\", \"nextRun\":\"%s\", \"pluginName\":\"%s\", \"pluginOutput\":\"%s\", \"pluginStatus\":\"%s\", \"pluginStatusChanged\":\"%s\", \"pluginStatusCode\":\"%d\"}}", hostName, kafka_id, g_plugins[storeIndex]->lastChangeTimestamp, currTime, pluginName, g_plugins[storeIndex]->nextRunTimestamp, g_plugins[storeIndex]->description, g_plugins[storeIndex]->output.retString, pluginStatus, g_plugins[storeIndex]->statusChanged, g_plugins[storeIndex]->output.retCode);
				json_object_object_add(j_root, "id", json_object_new_int(nKafkaId));
        		}
        		else if (kafka_export_addons == KAFKA_EXPORT_IDTAG) {
        			sprintf(payload, "{\"name\":\"%s\", \"id\":\"%s\",\"tag\":\"%s\", \"data\": {\"lastChange\":\"%s\", \"lastRun\":\"%s\", \"name\":\"%s\", \"nextRun\":\"%s\", \"pluginName\":\"%s\", \"pluginOutput\":\"%s\", \"pluginStatus\":\"%s\", \"pluginStatusChanged\":\"%s\", \"pluginStatusCode\":\"%d\"}}", hostName, kafka_id, kafka_tag, g_plugins[storeIndex]->lastChangeTimestamp, currTime, pluginName, g_plugins[storeIndex]->nextRunTimestamp, g_plugins[storeIndex]->description, g_plugins[storeIndex]->output.retString, pluginStatus, g_plugins[storeIndex]->statusChanged, g_plugins[storeIndex]->output.retCode);
                        }
			
                }*/
		if (kafka_export_addons == KAFKA_EXPORT_TAG || kafka_export_addons == KAFKA_EXPORT_IDTAG) {
        		json_object_object_add(j_root, "tag", json_object_new_string(kafka_tag));
    		}

    		if (kafka_export_addons == KAFKA_EXPORT_ID || kafka_export_addons == KAFKA_EXPORT_IDTAG) {
        		int nKafkaId = kafka_start_id + storeIndex;
        		// json-c can handle ints directly, or you can convert to string:
        		json_object_object_add(j_root, "id", json_object_new_int(nKafkaId)); 
    		}
	}
	json_object_object_add(j_root, "data", j_data);
	if (enableCollector) {
                if (collector_metadata) {
                        struct json_object *labels = get_labels_by_id(storeIndex);
                        if (labels) {
                                json_object_get(labels);
                                json_object_object_add(j_root, "labels", labels);
                        }
                }
                if (collector_metrics) {
                        struct json_object *perf = parse_perfdata(g_plugins[storeIndex]->output.retString);
                        if (perf) {
                                json_object_object_add(j_root, "metrics", perf);
                        }

                }
        }

	const char *serialized_json = json_object_to_json_string(j_root);
	char *payload = strdup(serialized_json);
	json_object_put(j_root);
	if (useKafkaConfigFile) {
		if (kafkaAvro) {
			int nKafkaId = kafka_start_id + storeIndex;
                        int length = snprintf(NULL, 0, "%d", nKafkaId);
                        char* kafka_id = malloc((size_t)length + 1);
                        snprintf(kafka_id, (size_t)length+1, "%d", nKafkaId);
			GKafkaMessage msg = {
                            .name = hostName,
                            .id = kafka_id,
                            .tag = kafka_tag,
                            .lastChange = g_plugins[storeIndex]->lastChangeTimestamp,
                            .lastRun = currTime,
                            .dataName = pluginName,
                            .nextRun = g_plugins[storeIndex]->nextRunTimestamp,
                            .pluginName = g_plugins[storeIndex]->description,
                            .pluginOutput = g_plugins[storeIndex]->output.retString,
                            .pluginStatus = pluginStatus,
                            .pluginStatusChanged = g_plugins[storeIndex]->statusChanged,
                            .pluginStatusCode = g_plugins[storeIndex]->output.retCode,
                            .labels = get_labels_by_id(storeIndex),
                            .metrics = parse_perfdata(g_plugins[storeIndex]->output.retString)
                        };
			send_avro_message_to_gkafka(kafka_brokers, kafka_topic, &msg);
			/* Requires synchronous consumption of msg; verify in mod_avro.c. */
			if (msg.metrics) json_object_put(msg.metrics);
			free(kafka_id);
		}
		else {
			send_message_to_gkafka(payload);
		}
		free(pluginName);
                free(pluginStatus);
                free(payload);
                pluginName = NULL;
                pluginStatus = NULL;
                payload = NULL;
                return;
	}
        if (!enableKafkaSSL) {
		if (!kafkaAvro) {
			send_message_to_kafka(kafka_brokers, kafka_topic, payload);
		}
		else {
			int nKafkaId = kafka_start_id + storeIndex;
                	int length = snprintf(NULL, 0, "%d", nKafkaId);
                	char* kafka_id = malloc((size_t)length + 1);
                	snprintf(kafka_id, (size_t)length+1, "%d", nKafkaId);
			GKafkaMessage msg = {
				.name = hostName,
    				.id = kafka_id,
    				.tag = kafka_tag,
    				.lastChange = g_plugins[storeIndex]->lastChangeTimestamp,
    				.lastRun = currTime,
    				.dataName = pluginName,
    				.nextRun = g_plugins[storeIndex]->nextRunTimestamp,
    				.pluginName = g_plugins[storeIndex]->description,
    				.pluginOutput = g_plugins[storeIndex]->output.retString,
    				.pluginStatus = pluginStatus,
    				.pluginStatusChanged = g_plugins[storeIndex]->statusChanged,
    				.pluginStatusCode = g_plugins[storeIndex]->output.retCode,
    				.labels = get_labels_by_id(storeIndex),
                                .metrics = parse_perfdata(g_plugins[storeIndex]->output.retString)
			};
			//send_avro_message_to_kafka(kafka_brokers, kafka_topic, hostName, kafka_id, kafka_tag, g_plugins[storeIndex]->lastChangeTimestamp, currTime, pluginName, g_plugins[storeIndex]->nextRunTimestamp, g_plugins[storeIndex]->description, g_plugins[storeIndex]->output.retString, pluginStatus, g_plugins[storeIndex]->statusChanged, g_plugins[storeIndex]->output.retCode);
			send_avro_message_to_gkafka(kafka_brokers, kafka_topic, &msg);
			/* Requires synchronous consumption of msg; verify in mod_avro.c. */
			if (msg.metrics) json_object_put(msg.metrics);
			free(kafka_id);
		}
	}
        else {
		if (!kafkaAvro) {
			send_ssl_message_to_kafka(kafka_brokers, kafkaCACertificate, kafkaProducerCertificate, kafkaSSLKey, kafka_topic, payload);
		}
		else {
			int nKafkaId = kafka_start_id + storeIndex;
                	int length = snprintf(NULL, 0, "%d", nKafkaId);
                	char* kafka_id = malloc((size_t)length + 1);
                	snprintf(kafka_id, (size_t)length+1, "%d", nKafkaId);
        		send_ssl_avro_message_to_kafka(kafka_brokers, kafkaCACertificate, kafkaProducerCertificate, kafkaSSLKey, kafka_topic, hostName, kafka_id, kafka_tag, g_plugins[storeIndex]->lastChangeTimestamp, currTime, pluginName, g_plugins[storeIndex]->nextRunTimestamp, g_plugins[storeIndex]->description, g_plugins[storeIndex]->output.retString, pluginStatus, g_plugins[storeIndex]->statusChanged, g_plugins[storeIndex]->output.retCode);
			free(kafka_id);
		}
	}
	free(pluginName);
        free(pluginStatus);
        pluginName = NULL;
        pluginStatus = NULL;
        free(payload);
        payload = NULL;
}
