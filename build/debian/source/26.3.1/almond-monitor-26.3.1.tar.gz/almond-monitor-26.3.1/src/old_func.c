static void add_plugin_status_metadata_json_minimal(struct json_object *object, const PluginItem *item) {
	struct json_object *history = json_object_new_array();
	for (size_t i = 0; i < item->historyCount; ++i) {
		struct json_object *entry = json_object_new_object();
		json_object_object_add(entry, "state",
							   json_object_new_string(plugin_status_name_json_minimal(
								   item->history[i].statusCode)));
		json_object_object_add(entry, "timestamp",
							   json_object_new_string(item->history[i].timestamp));
		json_object_array_add(history, entry);
	}
	json_object_object_add(object, "previousStatus",
						   json_object_new_string(plugin_status_name_json_minimal(
							   item->output.prevRetCode)));
	json_object_object_add(object, "statusChanged",
						   json_object_new_boolean(item->statusChanged[0] == '1'));
	json_object_object_add(object, "statusChangedAt",
						   json_object_new_string(item->statusChangedAt));
	json_object_object_add(object, "statusDuration",
						   json_object_new_int64(item->statusDuration));
	json_object_object_add(object, "history", history);
}
