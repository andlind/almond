#ifndef MAIN_H
#define MAIN_H

extern void writeLog(const char*, int);

#endif // MOD_KAFKA_H
