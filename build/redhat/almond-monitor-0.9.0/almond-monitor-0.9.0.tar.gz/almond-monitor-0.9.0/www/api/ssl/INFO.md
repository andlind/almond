This is a spot where to put certificates used by howru-api
