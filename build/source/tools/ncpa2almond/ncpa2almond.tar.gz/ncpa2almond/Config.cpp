#include "Config.hpp"

#include <fstream>
#include <stdexcept>


Config loadConfig(const std::string& filename)
{
    // Open configuration file
    std::ifstream file(filename);

    if (!file.is_open()) {
        throw std::runtime_error(
            "Could not open config file: " + filename
        );
    }


    // Parse JSON
    nlohmann::json root;

    try {
        file >> root;
    }
    catch (const nlohmann::json::parse_error& e) {
        throw std::runtime_error(
            "Invalid JSON in config file: " +
            std::string(e.what())
        );
    }


    Config config;


    // ------------------------------------------------------------
    // Global configuration
    // ------------------------------------------------------------
    config.host =
	 root.at("host").get<std::string>();

    config.outputFile =
        root.at("outputFile").get<std::string>();

    config.baseUrl =
        root.at("baseUrl").get<std::string>();

    config.token =
        root.at("token").get<std::string>();

    config.verifyTls =
        root.value("verifyTls", false);

    config.useCollect = 
        root.value("useCollect", false);

    config.usePush = 
	root.value("usePush", false);

    config.pushUrl = 
	root.at("pushUrl").get<std::string>();

    config.dataDir =
	root.at("dataDir").get<std::string>();

    config.pushPort = 
	root.at("pushPort").get<int>();

    config.removeFile = 
	root.value("removeFileAtStop", true);

    config.startupSleepSeconds =
	root.at("initialSleep").get<int>();


    // ------------------------------------------------------------
    // Checks
    // ------------------------------------------------------------

    if (!root.contains("checks") ||
        !root["checks"].is_array()) {

        throw std::runtime_error(
            "Config must contain a 'checks' array"
        );
    }


    for (const auto& item : root["checks"]) {

        CheckConfig check;


        check.name =
            item.at("name").get<std::string>();

        check.description =
            item.at("description").get<std::string>();

        check.url =
            item.at("url").get<std::string>();

        check.maintenance =
            item.value("maintenance", false);

        check.check =
            item.at("check").get<int>();

	check.runInterval = 
	    item.at("interval").get<int>();

        check.warning =
            item.at("warning").get<int>();

        check.critical =
            item.at("critical").get<int>();

        check.aggregate =
            item.value("aggregate", "");

        check.labels =
            item.value(
                "labels",
                nlohmann::json::object()
            );


        config.checks.push_back(check);
    }


    return config;
}

