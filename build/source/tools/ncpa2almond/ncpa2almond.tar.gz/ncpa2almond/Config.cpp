#include "Config.hpp"

#include <fstream>
#include <iostream>
#include <stdexcept>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

// Check config
//bool validate_config(const json& config)
bool validate_config(const json& config)
{
    // ---------------------------------------------------------
    // Helper for required fields
    // ---------------------------------------------------------

    auto require = [&](const json& obj,
                       const std::string& key,
                       json::value_t type) -> bool {

        if (!obj.contains(key)) {
            std::cerr
                << "ERROR: Missing required configuration entry: "
                << key
                << std::endl;

            return false;
        }

        const auto& value = obj.at(key);

        // Integers: accept both signed and unsigned JSON integers
        if (type == json::value_t::number_integer) {

            if (!value.is_number_integer() &&
                !value.is_number_unsigned()) {

                std::cerr
                    << "ERROR: Configuration entry '"
                    << key
                    << "' must be an integer."
                    << std::endl;

                return false;
            }

            return true;
        }

        // Everything else: exact type match
        if (value.type() != type) {

            std::cerr
                << "ERROR: Configuration entry '"
                << key
                << "' has invalid type."
                << std::endl;

            return false;
        }

        return true;
    };


    // ---------------------------------------------------------
    // Top-level configuration
    // ---------------------------------------------------------

    if (!require(config, "outputFile", json::value_t::string))
        return false;

    if (!require(config, "metricsFile", json::value_t::string))
        return false;

    if (!require(config, "metricsPrefix", json::value_t::string))
        return false;

    if (!require(config, "host", json::value_t::string))
        return false;

    if (!require(config, "useCollect", json::value_t::boolean))
        return false;

    if (!require(config, "usePush", json::value_t::boolean))
        return false;

    if (!require(config, "pushPort", json::value_t::number_integer))
        return false;

    if (!require(config, "pushUrl", json::value_t::string))
        return false;

    if (!require(config, "dataDir", json::value_t::string))
        return false;

    if (!require(config, "logDir", json::value_t::string))
        return false;

    if (!require(config, "removeFileAtStop", json::value_t::boolean))
        return false;

    if (!require(config, "initialSleep", json::value_t::number_integer))
        return false;

    if (!require(config, "baseUrl", json::value_t::string))
        return false;

    if (!require(config, "token", json::value_t::string))
        return false;

    if (!require(config, "verifyTls", json::value_t::boolean))
        return false;

    if (!require(config, "checks", json::value_t::array))
        return false;


    // ---------------------------------------------------------
    // Validate top-level values
    // ---------------------------------------------------------

    const int pushPort =
        config.at("pushPort").get<int>();

    if (pushPort < 0 || pushPort > 65535) {

        std::cerr
            << "ERROR: pushPort must be between 0 and 65535."
            << std::endl;

        return false;
    }


    const int initialSleep =
        config.at("initialSleep").get<int>();

    if (initialSleep < 0) {

        std::cerr
            << "ERROR: initialSleep cannot be negative."
            << std::endl;

        return false;
    }


    // ---------------------------------------------------------
    // Validate checks
    // ---------------------------------------------------------

    int checkIndex = 0;

    for (const auto& check : config.at("checks")) {

        // -----------------------------------------------------
        // Check must be an object
        // -----------------------------------------------------

        if (!check.is_object()) {

            std::cerr
                << "ERROR: checks["
                << checkIndex
                << "] must be an object."
                << std::endl;

            return false;
        }


        // -----------------------------------------------------
        // Helper for check fields
        // -----------------------------------------------------

        auto requireCheck = [&](const std::string& key,
                                json::value_t type) -> bool {

            if (!check.contains(key)) {

                std::cerr
                    << "ERROR: Missing checks["
                    << checkIndex
                    << "]."
                    << key
                    << std::endl;

                return false;
            }

            const auto& value = check.at(key);

            // Integer fields
            if (type == json::value_t::number_integer) {

                if (!value.is_number_integer() &&
                    !value.is_number_unsigned()) {

                    std::cerr
                        << "ERROR: checks["
                        << checkIndex
                        << "]."
                        << key
                        << " has invalid type."
                        << std::endl;

                    return false;
                }

                return true;
            }

            // Everything else
            if (value.type() != type) {

                std::cerr
                    << "ERROR: checks["
                    << checkIndex
                    << "]."
                    << key
                    << " has invalid type."
                    << std::endl;

                return false;
            }

            return true;
        };


        // -----------------------------------------------------
        // Required check fields
        // -----------------------------------------------------

        if (!requireCheck("name", json::value_t::string))
            return false;

        if (!requireCheck("description", json::value_t::string))
            return false;

        if (!requireCheck("url", json::value_t::string))
            return false;

        if (!requireCheck("maintenance", json::value_t::boolean))
            return false;

        if (!requireCheck("check", json::value_t::number_integer))
            return false;

        if (!requireCheck("interval", json::value_t::number_integer))
            return false;

        if (!requireCheck("warning", json::value_t::number_integer))
            return false;

        if (!requireCheck("critical", json::value_t::number_integer))
            return false;

        if (!requireCheck("labels", json::value_t::object))
            return false;


        // -----------------------------------------------------
        // Validate name
        // -----------------------------------------------------

        if (check.at("name").get<std::string>().empty()) {

            std::cerr
                << "ERROR: checks["
                << checkIndex
                << "].name cannot be empty."
                << std::endl;

            return false;
        }


        // -----------------------------------------------------
        // Validate URL
        // -----------------------------------------------------

        if (check.at("url").get<std::string>().empty()) {

            std::cerr
                << "ERROR: checks["
                << checkIndex
                << "].url cannot be empty."
                << std::endl;

            return false;
        }


        // -----------------------------------------------------
        // Validate interval
        // -----------------------------------------------------

        const int interval =
            check.at("interval").get<int>();

        if (interval <= 0) {

            std::cerr
                << "ERROR: checks["
                << checkIndex
                << "].interval must be greater than 0."
                << std::endl;

            return false;
        }


        // -----------------------------------------------------
        // Validate warning / critical
        // -----------------------------------------------------

        const int warning =
            check.at("warning").get<int>();

        const int critical =
            check.at("critical").get<int>();

        if (warning < 0 || critical < 0) {

            std::cerr
                << "ERROR: checks["
                << checkIndex
                << "] warning/critical cannot be negative."
                << std::endl;

            return false;
        }

        if (warning >= critical) {

            std::cerr
                << "ERROR: checks["
                << checkIndex
                << "] warning must be less than critical."
                << std::endl;

            return false;
        }


        // -----------------------------------------------------
        // Validate optional aggregate
        // -----------------------------------------------------

        if (check.contains("aggregate")) {

            const auto& aggregateValue =
                check.at("aggregate");

            if (!aggregateValue.is_string()) {

                std::cerr
                    << "ERROR: checks["
                    << checkIndex
                    << "].aggregate has invalid type."
                    << std::endl;

                return false;
            }

            const std::string aggregate =
                aggregateValue.get<std::string>();

            if (aggregate != "avg" &&
                aggregate != "sum" &&
                aggregate != "min" &&
                aggregate != "max") {

                std::cerr
                    << "ERROR: checks["
                    << checkIndex
                    << "].aggregate has invalid value: "
                    << aggregate
                    << std::endl;

                return false;
            }
        }


        // -----------------------------------------------------
        // Validate labels
        // -----------------------------------------------------

        for (const auto& [labelName, labelValue] :
             check.at("labels").items()) {

            if (!labelValue.is_string()) {

                std::cerr
                    << "ERROR: checks["
                    << checkIndex
                    << "].labels."
                    << labelName
                    << " must be a string."
                    << std::endl;

                return false;
            }
        }


        ++checkIndex;
    }


    // ---------------------------------------------------------
    // Everything is valid
    // ---------------------------------------------------------

    return true;
}

Config loadConfig(const std::string& filename)
{
    // Open configuration file
    std::ifstream file(filename);

    if (!file.is_open()) {
        throw std::runtime_error(
            "Could not open config file: " + filename
        );
    }

    // Parse JSON
    nlohmann::json root;

    try {
        file >> root;
    }
    catch (const nlohmann::json::parse_error& e) {
        throw std::runtime_error(
            "Invalid JSON in config file: " +
            std::string(e.what())
        );
    }
    
    if (!validate_config(root)) {
        throw std::runtime_error(
            "Configuration validation failed."
        );
    }

    Config config;


    // ------------------------------------------------------------
    // Global configuration
    // ------------------------------------------------------------
    config.host =
	 root.at("host").get<std::string>();

    config.outputFile =
        root.at("outputFile").get<std::string>();

    config.metricsFile= 
	root.at("metricsFile").get<std::string>();

    config.metricsPrefix = 
	root.at("metricsPrefix").get<std::string>();

    config.baseUrl =
        root.at("baseUrl").get<std::string>();

    config.token =
        root.at("token").get<std::string>();

    config.verifyTls =
        root.value("verifyTls", false);

    config.useCollect = 
        root.value("useCollect", false);

    config.usePush = 
	root.value("usePush", false);

    config.pushUrl = 
	root.at("pushUrl").get<std::string>();

    config.dataDir =
	root.at("dataDir").get<std::string>();

    config.logDir = 
	root.at("logDir").get<std::string>();

    config.pushPort = 
	root.at("pushPort").get<int>();

    config.removeFile = 
	root.value("removeFileAtStop", true);

    config.startupSleepSeconds =
	root.at("initialSleep").get<int>();


    // ------------------------------------------------------------
    // Checks
    // ------------------------------------------------------------

    if (!root.contains("checks") ||
        !root["checks"].is_array()) {

        throw std::runtime_error(
            "Config must contain a 'checks' array"
        );
    }


    for (const auto& item : root["checks"]) {

        CheckConfig check;


        check.name =
            item.at("name").get<std::string>();

        check.description =
            item.at("description").get<std::string>();

        check.url =
            item.at("url").get<std::string>();

        check.maintenance =
            item.value("maintenance", false);

        check.check =
            item.at("check").get<int>();

	check.runInterval = 
	    item.at("interval").get<int>();

        check.warning =
            item.at("warning").get<int>();

        check.critical =
            item.at("critical").get<int>();

        check.aggregate =
            item.value("aggregate", "");

        check.labels =
            item.value(
                "labels",
                nlohmann::json::object()
            );


        config.checks.push_back(check);
    }


    return config;
}

