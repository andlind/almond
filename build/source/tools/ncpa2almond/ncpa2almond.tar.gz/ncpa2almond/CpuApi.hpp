#pragma once

#include "Config.hpp"

#include <string>

std::string getCpuData(const Config& config);
