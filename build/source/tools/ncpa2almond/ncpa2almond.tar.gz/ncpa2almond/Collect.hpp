#pragma once

#include <string>

struct SystemSnapshot {
    std::string hostname;
    std::string os;
    int cpu_cores = 1;
    double load_average = 0.0;
    long long total_memory_kb = 0;
    long long free_memory_kb = 0;
    long long used_memory_kb = 0;
    long long disk_total_kb = 0;
    long long disk_free_kb = 0;
    long long disk_used_kb = 0;
    long long network_rx_bytes = 0;
    long long network_tx_bytes = 0;
    long long process_count = 0;
    long long uptime_seconds = 0;
};

SystemSnapshot collect_snapshot();
std::string to_json(const SystemSnapshot& snapshot);
