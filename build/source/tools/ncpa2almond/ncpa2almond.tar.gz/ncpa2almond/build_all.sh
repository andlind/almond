#!/usr/bin/env bash
set -e

echo "=== Building Linux Binary ==="
cmake --preset linux-release
cmake --build --preset linux

echo "=== Building Windows Binary ==="
cmake --preset windows-release
cmake --build --preset windows

echo "=== Done! Binaries generated in ./build/linux and ./build/windows ==="
