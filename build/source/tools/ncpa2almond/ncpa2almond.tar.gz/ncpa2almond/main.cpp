#include "Config.hpp"
#include "ApiClient.hpp"

#include <nlohmann/json.hpp>

#include <iostream>
#include <fstream>
#include <exception>
#include <string>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>

using json = nlohmann::json;


// Return current time as:
// 2026-08-31 12:37:12
std::string currentTime()
{
    auto now = std::chrono::system_clock::now();
    std::time_t time =
        std::chrono::system_clock::to_time_t(now);

    std::tm tm{};

#ifdef _WIN32
    localtime_s(&tm, &time);
#else
    localtime_r(&time, &tm);
#endif

    std::ostringstream oss;

    oss << std::put_time(
        &tm,
        "%Y-%m-%d %H:%M:%S"
    );

    return oss.str();
}


int main(int argc, char* argv[])
{
    const std::string configFile =
        argc > 1 ? argv[1] : "config.json";

    try {

        // --------------------------------------------------------
        // Load configuration
        // --------------------------------------------------------

        Config config =
            loadConfig(configFile);


        // --------------------------------------------------------
        // Open output file
        // --------------------------------------------------------

        std::ofstream outputFile(
            config.outputFile
        );

        if (!outputFile.is_open()) {

            throw std::runtime_error(
                "Could not open output file: " +
                config.outputFile
            );
        }


        // All check results go into this array
        json results = json::array();


        // --------------------------------------------------------
        // Execute checks
        // --------------------------------------------------------

        for (const auto& check : config.checks) {

            try {

                // Execute check using the global
                // base URL and token.
                std::string response =
                    executeCheck(
                        check,
                        config.baseUrl,
                        config.token,
                        config.verifyTls
                    );


                // Response from the API/plugin:
                //
                // {
                //     "returncode": 0,
                //     "stdout": "OK: Percent was 2.05 % | ..."
                // }
                //
                json result =
                    json::parse(response);


                int returnCode =
                    result.value(
                        "returncode",
                        3
                    );


                std::string stdoutText =
                    result.value(
                        "stdout",
                        ""
                    );


                // ------------------------------------------------
                // Convert return code to plugin status
                // ------------------------------------------------

                std::string pluginStatus;

                switch (returnCode) {

                    case 0:
                        pluginStatus = "OK";
                        break;

                    case 1:
                        pluginStatus = "WARNING";
                        break;

                    case 2:
                        pluginStatus = "CRITICAL";
                        break;

                    default:
                        pluginStatus = "UNKNOWN";
                        returnCode = 3;
                        break;
                }


                // ------------------------------------------------
                // Timestamp
                // ------------------------------------------------

                std::string now =
                    currentTime();


                // ------------------------------------------------
                // Build output entry
                // ------------------------------------------------

                json entry = {

                    {"name",
                     check.name},

                    {"pluginName",
                     check.description},

                    {"pluginStatus",
                     pluginStatus},

                    {"pluginStatusCode",
                     returnCode},

                    {"pluginOutput",
                     stdoutText},

                    {"pluginStatusChanged",
                     "0"},

                    {"maintenance",
                     check.maintenance},

                    {"lastChange",
                     now},

                    {"lastRun",
                     now},

                    {"nextRun",
                     ""},

                    {"labels",
                     check.labels}
                };


                results.push_back(entry);
            }


            // ----------------------------------------------------
            // Check failed
            // ----------------------------------------------------

            catch (const std::exception& e) {

                std::string now =
                    currentTime();


                results.push_back({

                    {"name",
                     check.name},

                    {"pluginName",
                     check.description},

                    {"pluginStatus",
                     "UNKNOWN"},

                    {"pluginStatusCode",
                     3},

                    {"pluginOutput",
                     e.what()},

                    {"pluginStatusChanged",
                     "0"},

                    {"maintenance",
                     check.maintenance},

                    {"lastChange",
                     now},

                    {"lastRun",
                     now},

                    {"nextRun",
                     ""},

                    {"labels",
                     check.labels}
                });
            }
        }


        // --------------------------------------------------------
        // Write JSON output
        // --------------------------------------------------------

        //outputFile
        //    << results.dump(2)
        //    << '\n';
        json output = {
    		{"host", {
        		{"name", config.host}
    		}},
    		{"monitoring", results}
	};
        outputFile
    		<< output.dump(2)
    		<< '\n';

        outputFile.close();
    }


    // ------------------------------------------------------------
    // Configuration / application error
    // ------------------------------------------------------------

    catch (const std::exception& e) {

        std::cerr
            << "ERROR: "
            << e.what()
            << '\n';

        return 1;
    }


    return 0;
}
