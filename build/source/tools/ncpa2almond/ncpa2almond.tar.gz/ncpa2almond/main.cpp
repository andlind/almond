#include "Config.hpp"
#include "ApiClient.hpp"
#include "Collect.hpp"

#include <nlohmann/json.hpp>

#include <iostream>
#include <fstream>
#include <exception>
#include <string>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>
#include <cstdio>
#include <thread>
#include <map>
#include <csignal>
#include <atomic>

using json = nlohmann::json;

// ----------------------------------------------------------------
// Global flag for graceful shutdown
// ----------------------------------------------------------------
std::atomic<bool> g_running{true};

void signalHandler(int signum) {
    g_running = false;
}

// ----------------------------------------------------------------
// Helpers
// ----------------------------------------------------------------
json buildHostJson(const Config& config, const SystemSnapshot& snapshot)
{
    json host = {
        {"name", config.host.empty() ? snapshot.hostname : config.host}
    };

    if (config.useCollect) {
        host["os"] = snapshot.os;
        host["cpu"] = {
            {"cores", snapshot.cpu_cores},
            {"load_average", snapshot.load_average}
        };
        host["memory"] = {
            {"total_kb", snapshot.total_memory_kb},
            {"free_kb", snapshot.free_memory_kb},
            {"used_kb", snapshot.used_memory_kb}
        };
        host["disk"] = {
            {"total_kb", snapshot.disk_total_kb},
            {"free_kb", snapshot.disk_free_kb},
            {"used_kb", snapshot.disk_used_kb}
        };
        host["network"] = {
            {"rx_bytes", snapshot.network_rx_bytes},
            {"tx_bytes", snapshot.network_tx_bytes}
        };
        host["process_count"] = snapshot.process_count;
        host["uptime_seconds"] = snapshot.uptime_seconds;
    }
    return host;
}

std::string formatTime(std::chrono::system_clock::time_point tp)
{
    std::time_t time = std::chrono::system_clock::to_time_t(tp);
    std::tm tm{};

#ifdef _WIN32
    localtime_s(&tm, &time);
#else
    localtime_r(&time, &tm);
#endif

    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
    return oss.str();
}

struct CheckState {
    std::chrono::steady_clock::time_point next_run_steady;
    std::chrono::system_clock::time_point next_run_system;
    json last_result;
    int last_status_code = -1;
    std::string last_change_time;
};

// ----------------------------------------------------------------
// Main
// ----------------------------------------------------------------
int main(int argc, char* argv[])
{
    // Register signal handlers for graceful shutdown (Ctrl+C and termination)
    std::signal(SIGINT, signalHandler);
    std::signal(SIGTERM, signalHandler);

    const std::string configFile = argc > 1 ? argv[1] : "config.json";

    try {
        Config config = loadConfig(configFile);
        std::map<std::string, CheckState> stateMap;

        // --------------------------------------------------------
        // Define reusable execution logic using a Lambda
        // --------------------------------------------------------
        auto processCheck = [&](const auto& check, CheckState& state, 
                                auto now_steady, auto now_system) {
            
            auto interval = std::chrono::minutes(check.runInterval);
            state.next_run_steady = now_steady + interval;
            state.next_run_system = now_system + interval;

            std::string currentRunStr = formatTime(now_system);
            std::string nextRunStr = formatTime(state.next_run_system);
            
            int returnCode = 3;
            std::string stdoutText = "";
            std::string pluginStatus = "UNKNOWN";

            try {
                std::string response = executeCheck(
                    check, config.baseUrl, config.token, config.verifyTls
                );

                json result = json::parse(response);
                returnCode = result.value("returncode", 3);
                stdoutText = result.value("stdout", "");

                switch (returnCode) {
                    case 0: pluginStatus = "OK"; break;
                    case 1: pluginStatus = "WARNING"; break;
                    case 2: pluginStatus = "CRITICAL"; break;
                    default: pluginStatus = "UNKNOWN"; returnCode = 3; break;
                }
            }
            catch (const std::exception& e) {
                returnCode = 3;
                pluginStatus = "UNKNOWN";
                stdoutText = e.what();
            }

            // Status changed logic
            std::string pluginStatusChanged = "0";
            if (state.last_status_code == -1) {
                state.last_status_code = returnCode;
                state.last_change_time = currentRunStr;
            } 
            else if (state.last_status_code != returnCode) {
                state.last_status_code = returnCode;
                state.last_change_time = currentRunStr;
                pluginStatusChanged = "1";
            }

            state.last_result = {
                {"name", check.name},
                {"pluginName", check.description},
                {"pluginStatus", pluginStatus},
                {"pluginStatusCode", returnCode},
                {"pluginOutput", stdoutText},
                {"pluginStatusChanged", pluginStatusChanged},
                {"maintenance", check.maintenance},
                {"lastChange", state.last_change_time},
                {"lastRun", currentRunStr},
                {"nextRun", nextRunStr},
                {"labels", check.labels}
            };
        };

        // --------------------------------------------------------
        // Define reusable file writing logic using a Lambda
        // --------------------------------------------------------
        auto writeOutputFile = [&]() {
            json results = json::array();
            for (const auto& check : config.checks) {
                if (!stateMap[check.name].last_result.empty()) {
                    results.push_back(stateMap[check.name].last_result);
                }
            }

            SystemSnapshot snapshot = collect_snapshot();
            json output = {
                {"host", buildHostJson(config, snapshot)},
                {"monitoring", results}
            };

            std::ofstream outputFile(config.outputFile);
            if (!outputFile.is_open()) {
                throw std::runtime_error("Could not open output file: " + config.outputFile);
            }
            outputFile << output.dump(2) << '\n';
        };

        // ========================================================
        // 1. STARTUP EXECUTION (Staggered by 4 seconds)
        // ========================================================
        std::cout << "Starting agent... performing initial checks." << std::endl;
        
        bool first_check = true;
        for (const auto& check : config.checks) {
            if (!g_running) break;

            if (!first_check && config.startupSleepSeconds > 0) {
                // Interruptible 4-second sleep between initial checks
                auto stagger_wake = std::chrono::steady_clock::now() + std::chrono::seconds(config.startupSleepSeconds);
                while (g_running && std::chrono::steady_clock::now() < stagger_wake) {
                    std::this_thread::sleep_for(std::chrono::milliseconds(200));
                }
            }
            if (!g_running) break;

            // Fetch fresh time exactly when this specific check runs
            auto now_steady = std::chrono::steady_clock::now();
            auto now_system = std::chrono::system_clock::now();
            
            processCheck(check, stateMap[check.name], now_steady, now_system);
            first_check = false;
        }

        if (g_running) {
            writeOutputFile();
        }

        // ========================================================
        // 2. ROLLING SCHEDULER LOOP
        // ========================================================
        if (g_running) {
            std::cout << "Initialization complete. Entering scheduler loop." << std::endl;
        }
        
        while (g_running) {
            // Find the time of the closest upcoming check
            auto now_steady = std::chrono::steady_clock::now();
            auto next_wake = now_steady + std::chrono::hours(1); 
            for (const auto& [name, state] : stateMap) {
                if (state.next_run_steady < next_wake) {
                    next_wake = state.next_run_steady;
                }
            }

            // Interruptible sleep loop: Checks `g_running` every 200ms
            while (g_running && std::chrono::steady_clock::now() < next_wake) {
                std::this_thread::sleep_for(std::chrono::milliseconds(200));
            }

            if (!g_running) break;

            now_steady = std::chrono::steady_clock::now();
            auto now_system = std::chrono::system_clock::now();
            bool file_needs_update = false;

            // Execute checks that are due
            for (const auto& check : config.checks) {
                auto& state = stateMap[check.name];
                if (now_steady >= state.next_run_steady) {
                    processCheck(check, state, now_steady, now_system);
                    file_needs_update = true;
                }
            }

            // Update file only if a check actually ran
            if (file_needs_update) {
                writeOutputFile();
            }
        }

        // ========================================================
        // 3. GRACEFUL SHUTDOWN CLEANUP
        // ========================================================
        std::cout << "\nShutting down gracefully..." << std::endl;
	if (config.removeFile) {
            std::cout << "Removing output file: " << config.outputFile << std::endl;

            // std::remove returns 0 on success
            if (std::remove(config.outputFile.c_str()) != 0) {
                // If it fails (e.g., file doesn't exist or permissions issue)
                std::cerr << "Warning: Could not remove file " << config.outputFile << '\n';
            }
        }

    }
    catch (const std::exception& e) {
        std::cerr << "ERROR: " << e.what() << '\n';
        return 1;
    }

    return 0;
}
