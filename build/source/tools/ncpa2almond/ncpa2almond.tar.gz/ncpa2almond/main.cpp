#include "Config.hpp"
#include "ApiClient.hpp"
#include "Collect.hpp"
#include "Logger.h"

#include <nlohmann/json.hpp>

#include <iostream>
#include <fstream>
#include <exception>
#include <string>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>
#include <cstdio>
#include <thread>
#include <map>
#include <stdexcept>
#include <regex>
#include <csignal>
#include <atomic>
#include <sys/stat.h>
#include <cstdio>
#include <memory>
#include <filesystem>
#include <vector>
#include <string_view>
#include <curl/curl.h>

using json = nlohmann::json;

struct PerformanceMetric {
    std::string key;
    std::string value;
};

extern "C" {

static size_t file_read_cb(char *ptr, size_t size, size_t nmemb, void *stream) {
    auto *f = static_cast<FILE*>(stream);
    return std::fread(ptr, size, nmemb, f);
}

/*static size_t write_cb(char *ptr, size_t size, size_t nmemb, void *userdata) {
    const size_t real_size = size * nmemb;
    auto *response_str = static_cast<std::string*>(userdata);

    response_str->append(ptr, real_size);
    return real_size;
}*/

static size_t write_callback(
    char* ptr,
    size_t size,
    size_t nmemb,
    void* userdata)
{
    auto* response = static_cast<std::string*>(userdata);

    const size_t bytes = size * nmemb;
    response->append(ptr, bytes);

    return bytes;
}

} // extern "C"

static bool contains_scheme(std::string_view s) {
	return s.rfind("http://", 0) == 0 || s.rfind("https://", 0) == 0;
}

static bool has_port_in_host(std::string_view s) {
    // Skip scheme if present
    size_t scheme_pos = s.find("://");
    if (scheme_pos != std::string_view::npos) {
        s.remove_prefix(scheme_pos + 3);
    }

    size_t slash = s.find('/');
    size_t colon = s.find(':');

    return (colon != std::string_view::npos) && (slash == std::string_view::npos || colon < slash);
}

static bool is_ipv6_literal_no_brackets(std::string_view s) {
    return !s.empty() &&
           (s.find(':') != std::string_view::npos) &&
           (s.front() != '[') &&
           !contains_scheme(s);
}

struct FileDeleter {
    void operator()(FILE* f) const noexcept {
        if (f) fclose(f);
    }
};

struct CurlHeaderDeleter {
    void operator()(curl_slist* slist) const noexcept {
        if (slist) curl_slist_free_all(slist);
    }
};

struct CurlDeleter {
    void operator()(CURL* c) const noexcept {
        if (c) curl_easy_cleanup(c);
    }
};

using FilePtr = std::unique_ptr<FILE, FileDeleter>;
using CurlPtr = std::unique_ptr<CURL, CurlDeleter>;
using CurlHeadersPtr = std::unique_ptr<curl_slist, CurlHeaderDeleter>;


// ----------------------------------------------------------------
// Global flag for graceful shutdown
// ----------------------------------------------------------------
std::atomic<bool> g_running{true};

void signalHandler(int signum) {
    g_running = false;
}

// ----------------------------------------------------------------
// Helpers
// ----------------------------------------------------------------
std::filesystem::path getOutputPath(const Config& config)
{
    return std::filesystem::path(config.dataDir) / config.outputFile;
}

std::string sanitizeMetricName(const std::string& name)
{
    std::string result;

    for (char c : name) {
        if ((c >= 'a' && c <= 'z') ||
            (c >= 'A' && c <= 'Z') ||
            (c >= '0' && c <= '9') ||
            c == '_') {
            result += c;
        } else {
            result += '_';
        }
    }

    return result;
}

json buildHostJson(const Config& config, const SystemSnapshot& snapshot)
{
    json host = {
        {"name", config.host.empty() ? snapshot.hostname : config.host}
    };

    if (config.useCollect) {
        host["os"] = snapshot.os;
        host["cpu"] = {
            {"cores", snapshot.cpu_cores},
            {"load_average", snapshot.load_average}
        };
        host["memory"] = {
            {"total_kb", snapshot.total_memory_kb},
            {"free_kb", snapshot.free_memory_kb},
            {"used_kb", snapshot.used_memory_kb}
        };
        host["disk"] = {
            {"total_kb", snapshot.disk_total_kb},
            {"free_kb", snapshot.disk_free_kb},
            {"used_kb", snapshot.disk_used_kb}
        };
        host["network"] = {
            {"rx_bytes", snapshot.network_rx_bytes},
            {"tx_bytes", snapshot.network_tx_bytes}
        };
        host["process_count"] = snapshot.process_count;
        host["uptime_seconds"] = snapshot.uptime_seconds;
    }
    return host;
}

std::string build_push_url(std::string_view push_url, int port, std::string_view path) {
    if (contains_scheme(push_url)) {
        if (has_port_in_host(push_url)) {
            // Already has port; just append path
            return std::string(push_url) + std::string(path);
        }

        // Find end of host (first '/' after "://")
        size_t scheme_pos = push_url.find("://");
        size_t search_start = (scheme_pos != std::string_view::npos) ? scheme_pos + 3 : 0;
        size_t host_end = push_url.find('/', search_start);

        if (host_end == std::string_view::npos) {
            return std::string(push_url) + ":" + std::to_string(port) + std::string(path);
        }

        // Insert :port before host_end path segment
        std::string result(push_url.substr(0, host_end));
        result += ":" + std::to_string(port);
        result += push_url.substr(host_end);
        result += path;
        return result;
    }

    // No scheme provided: default to HTTP
    if (is_ipv6_literal_no_brackets(push_url)) {
        return "http://[" + std::string(push_url) + "]:" + std::to_string(port) + std::string(path);
    }

    return "http://" + std::string(push_url) + ":" + std::to_string(port) + std::string(path);
}

int generate_prometheus_file(
    const std::filesystem::path& inputPath,
    const std::filesystem::path& promPath, const std::string& metricsPrefix)
{
    std::ifstream inputFile(inputPath);

    if (!inputFile.is_open()) {
        std::cout
            << "Could not open input file '"
            << inputPath.string()
            << "' for file handling."
            << std::endl;

        return -1;
    }

    json input;

    try {
        inputFile >> input;
    }
    catch (const json::exception& e) {
        std::cout
            << "Could not parse JSON file '"
            << inputPath.string()
            << "': "
            << e.what()
            << std::endl;

        return -1;
    }

    if (!input.contains("host") ||
        !input["host"].contains("name")) {

        std::cout
            << "Input JSON does not contain host.name."
            << std::endl;

        return -1;
    }

    const std::string hostname =
        input.at("host").at("name").get<std::string>();

    std::ofstream promFile(promPath);

    if (!promFile.is_open()) {
        std::cout
            << "Could not open output file '"
            << promPath.string()
            << "' for writing."
            << std::endl;

        return -1;
    }

    // ---------------------------------------------------------
    // Check monitoring data
    // ---------------------------------------------------------

    if (!input.contains("monitoring") ||
        !input["monitoring"].is_array()) {

        std::cout
            << "WARN: JSON export does not contain monitoring data."
            << std::endl;

        return 0;
    }

    // ---------------------------------------------------------
    // Iterate through monitoring checks
    // ---------------------------------------------------------

    for (const auto& check : input.at("monitoring")) {

        if (!check.contains("name") ||
            !check.contains("pluginOutput") ||
            !check.contains("pluginName")) {

            continue;
        }

        const std::string checkName =
            check.at("name").get<std::string>();

        const std::string pluginName =
            check.at("pluginName").get<std::string>();

        const std::string pluginOutput =
            check.at("pluginOutput").get<std::string>();

        // -----------------------------------------------------
        // Find performance data after '|'
        // -----------------------------------------------------

        const auto pipePos =
            pluginOutput.find('|');

        if (pipePos == std::string::npos) {
            continue;
        }

        const std::string perfData =
            pluginOutput.substr(pipePos + 1);

        // -----------------------------------------------------
        // Parse performance data
        //
        // Example:
        //
        // 'percent_0'=16.00%;70;85;
        // 'percent_1'=24.00%;70;85;
        //
        // Captures:
        //
        // [1] = key
        // [2] = value
        // [3] = unit
        // -----------------------------------------------------

        std::regex perfRegex(
            R"('([^']+)'=([-+]?[0-9]*\.?[0-9]+)([a-zA-Z%]*)(?:;[^ ]*)?)"
        );

        std::vector<PerformanceMetric> metrics;

        auto begin = std::sregex_iterator(
            perfData.begin(),
            perfData.end(),
            perfRegex
        );

        auto end = std::sregex_iterator();

        // -----------------------------------------------------
        // Collect ALL metrics first
        // -----------------------------------------------------

        for (auto it = begin; it != end; ++it) {

            const std::smatch& match = *it;

            PerformanceMetric metric;

            metric.key = match[1].str();
            metric.value = match[2].str();

            metrics.push_back(metric);
        }

        // -----------------------------------------------------
        // No performance data
        // -----------------------------------------------------

        if (metrics.empty()) {
            continue;
        }

        // -----------------------------------------------------
        // Determine if this check has multiple metrics
        // -----------------------------------------------------

        const bool multipleMetrics =
            metrics.size() > 1;

        const std::string sanitizedCheckName =
            sanitizeMetricName(checkName);

        // -----------------------------------------------------
        // Write metrics
        // -----------------------------------------------------

        for (const auto& metric : metrics) {

            const std::string sanitizedKey =
                sanitizeMetricName(metric.key);

            std::string metricName =
                metricsPrefix + "_" +
                sanitizedCheckName +
                "_" +
                sanitizedKey;

            promFile
                << metricName
                << "{hostname=\"" << hostname
                << "\", service=\"" << pluginName << "\"";

            // Only add key when there are multiple metrics
            if (multipleMetrics) {
                promFile
                    << ", key=\"" << metric.key << "\"";
            }

            promFile
                << "} "
                << metric.value
                << '\n';
        }
    }

    return 0;
}

/*int post_json_file_stream(const char *url, const char *filepath) {
    std::unique_ptr<FILE, FileDeleter> f(fopen(filepath, "rb"));
    if (!f) {
        //snprintf(infostr, infostr_size, "[push_json] Can not open file '%s'.", filepath);
        //writeLog(infostr, 1, 0);
        fprintf(stderr, "ERROR: cannot open file '%s'\n", filepath);
        return -1;
    }

    struct stat st;
    if (fstat(fileno(f.get()), &st) != 0) {
        //snprintf(infostr, infostr_size, "[push_json] fstat failed for '%s'.", filepath);
        //writeLog(infostr, 1, 0);
        fprintf(stderr, "ERROR: fstat failed for '%s'\n", filepath);
        return -1;
    }

    curl_global_init(CURL_GLOBAL_DEFAULT);

    std::unique_ptr<CURL, CurlDeleter> c(curl_easy_init());
    if (!c) {
        curl_global_cleanup();
        return -1;
    }
    std::unique_ptr<curl_slist, SListDeleter> hdrs(curl_slist_append(nullptr, "Content-Type: application/json"));

    curl_easy_setopt(c.get(), CURLOPT_HTTPHEADER, hdrs.get());
    curl_easy_setopt(c.get(), CURLOPT_URL, url);
    curl_easy_setopt(c.get(), CURLOPT_POST, 1L);
    curl_easy_setopt(c.get(), CURLOPT_READFUNCTION, file_read_cb);
    curl_easy_setopt(c.get(), CURLOPT_READDATA, f.get());
    curl_easy_setopt(c.get(), CURLOPT_POSTFIELDSIZE_LARGE, static_cast<curl_off_t>(st.st_size));
    curl_easy_setopt(c.get(), CURLOPT_WRITEFUNCTION, write_cb);

    // FIX: Replaced 'struct resp_buf rb = { nullptr, 0 };' with std::string
    std::string response_body;
    curl_easy_setopt(c.get(), CURLOPT_WRITEDATA, &response_body);

    curl_easy_setopt(c.get(), CURLOPT_VERBOSE, 1L);
    curl_easy_setopt(c.get(), CURLOPT_TIMEOUT, 30L);

    CURLcode res = curl_easy_perform(c.get());
    int rc = -1;

    if (res != CURLE_OK) {
        //snprintf(infostr, infostr_size, "[push_json] curl_easy_perform failed: %s.", curl_easy_strerror(res));
        //writeLog(infostr, 1, 0);
        fprintf(stderr, "curl_easy_perform failed: %s\n", curl_easy_strerror(res));
    } else {
        long http_code = 0;
        curl_easy_getinfo(c.get(), CURLINFO_RESPONSE_CODE, &http_code);
        //snprintf(infostr, infostr_size, "[push_json] HTTP status: '%ld'.", http_code);
        //writeLog(infostr, 0, 0);
        fprintf(stderr, "HTTP status: %ld\n", http_code);
        if (!response_body.empty())
            fprintf(stderr, "Response body: %s\n", response_body.c_str());
        rc = (http_code >= 200 && http_code < 300) ? 0 : -1;
    }

    curl_global_cleanup();
    return rc;
}*/

int post_file(
    const char* url,
    const char* filepath,
    const char* contentType)
{
    if (!url || !filepath || !contentType) {
        std::cerr << "ERROR: invalid argument\n";
        return -1;
    }

    FilePtr file{std::fopen(filepath, "rb")};

    if (!file) {
        std::cerr << "ERROR: cannot open file '"
                  << filepath << "'\n";
        return -1;
    }

    struct stat st{};

    if (fstat(fileno(file.get()), &st) != 0) {
        std::cerr << "ERROR: fstat failed for '"
                  << filepath << "'\n";
        return -1;
    }

    CurlPtr curl{curl_easy_init()};

    if (!curl) {
        std::cerr << "ERROR: curl_easy_init failed\n";
        return -1;
    }

    CurlHeadersPtr headers{
        curl_slist_append(nullptr, contentType)
    };

    if (!headers) {
        std::cerr << "ERROR: failed to create HTTP headers\n";
        return -1;
    }

    std::string response;

    curl_easy_setopt(curl.get(), CURLOPT_URL, url);
    curl_easy_setopt(curl.get(), CURLOPT_HTTPHEADER, headers.get());
    curl_easy_setopt(curl.get(), CURLOPT_POST, 1L);

    curl_easy_setopt(curl.get(), CURLOPT_READFUNCTION, file_read_cb);
    curl_easy_setopt(curl.get(), CURLOPT_READDATA, file.get());

    curl_easy_setopt(
        curl.get(),
        CURLOPT_POSTFIELDSIZE_LARGE,
        static_cast<curl_off_t>(st.st_size)
    );

    curl_easy_setopt(curl.get(), CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl.get(), CURLOPT_WRITEDATA, &response);

    curl_easy_setopt(curl.get(), CURLOPT_VERBOSE, 1L);
    curl_easy_setopt(curl.get(), CURLOPT_TIMEOUT, 30L);

    const CURLcode result = curl_easy_perform(curl.get());

    if (result != CURLE_OK) {
        std::cerr << "curl_easy_perform failed: "
                  << curl_easy_strerror(result) << '\n';
        return -1;
    }

    long httpCode = 0;

    curl_easy_getinfo(
        curl.get(),
        CURLINFO_RESPONSE_CODE,
        &httpCode
    );

    std::cerr << "HTTP status: " << httpCode << '\n';

    if (!response.empty()) {
        std::cerr << "Response body: "
                  << response << '\n';
    }

    return (httpCode >= 200 && httpCode < 300)
        ? 0
        : -1;
}

int post_json_file_stream(
    const char* url,
    const char* filepath)
{
    return post_file(
        url,
        filepath,
        "Content-Type: application/json"
    );
}

// -----------------------------------------------------------------------------
// Metrics POST functions
// -----------------------------------------------------------------------------

int post_metrics_file_stream(
    const char* url,
    const char* filepath)
{
    return post_file(
        url,
        filepath,
        "Content-Type: text/plain; version=0.0.4; charset=utf-8"
    );
}

int post_openmetrics_file_stream(
    const char* url,
    const char* filepath)
{
    return post_file(
        url,
        filepath,
        "Content-Type: application/openmetrics-text; version=1.0.0; charset=utf-8"
    );
}

/*int main(int argc, char* argv[])
{
    // Initialize libcurl once for the entire application.
    const CURLcode curlResult =
        curl_global_init(CURL_GLOBAL_DEFAULT);

    if (curlResult != CURLE_OK) {
        std::cerr << "ERROR: curl_global_init failed: "
                  << curl_easy_strerror(curlResult) << '\n';
        return 1;
    }

    // Everything that uses libcurl should happen while it is initialized.
    //
    // ... your existing application code ...
    //
    // Example:
    //
    // const int result =
    //     post_metrics_file_stream(
    //         "http://localhost:9090/api/v1/import",
    //         "metrics.txt"
    //     );

    // Shut down libcurl once when the application is finished.
    curl_global_cleanup();

    return 0;
}*/

std::string formatTime(std::chrono::system_clock::time_point tp)
{
    std::time_t time = std::chrono::system_clock::to_time_t(tp);
    std::tm tm{};

#ifdef _WIN32
    localtime_s(&tm, &time);
#else
    localtime_r(&time, &tm);
#endif

    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
    return oss.str();
}

struct CheckState {
    std::chrono::steady_clock::time_point next_run_steady;
    std::chrono::system_clock::time_point next_run_system;
    json last_result;
    int last_status_code = -1;
    std::string last_change_time;
};

// ----------------------------------------------------------------
// Main
// ----------------------------------------------------------------
int main(int argc, char* argv[])
{
    // Register signal handlers for graceful shutdown (Ctrl+C and termination)
    std::signal(SIGINT, signalHandler);
    std::signal(SIGTERM, signalHandler);

    const std::string configFile = argc > 1 ? argv[1] : "config.json";

    try {
        Config config = loadConfig(configFile);

	Logger logger(std::filesystem::path(config.logDir) / "ncpa2almond.log");
	logger.info("Starting ncpa2almond 0.9.1");
	logger.info("Configuration loaded");

        std::map<std::string, CheckState> stateMap;

        // --------------------------------------------------------
        // Define reusable execution logic using a Lambda
        // --------------------------------------------------------
        auto processCheck = [&](const auto& check, CheckState& state, 
                                auto now_steady, auto now_system) {
            
            auto interval = std::chrono::minutes(check.runInterval);
            state.next_run_steady = now_steady + interval;
            state.next_run_system = now_system + interval;

            std::string currentRunStr = formatTime(now_system);
            std::string nextRunStr = formatTime(state.next_run_system);
            
            int returnCode = 3;
            std::string stdoutText = "";
            std::string pluginStatus = "UNKNOWN";

            try {
                std::string response = executeCheck(
                    check, config.baseUrl, config.token, config.verifyTls
                );

                json result = json::parse(response);
                returnCode = result.value("returncode", 3);
                stdoutText = result.value("stdout", "");

                switch (returnCode) {
                    case 0: pluginStatus = "OK"; break;
                    case 1: pluginStatus = "WARNING"; break;
                    case 2: pluginStatus = "CRITICAL"; break;
                    default: pluginStatus = "UNKNOWN"; returnCode = 3; break;
                }
            }
            catch (const std::exception& e) {
                returnCode = 3;
                pluginStatus = "UNKNOWN";
                stdoutText = e.what();
            }

            // Status changed logic
            std::string pluginStatusChanged = "0";
            if (state.last_status_code == -1) {
                state.last_status_code = returnCode;
                state.last_change_time = currentRunStr;
            } 
            else if (state.last_status_code != returnCode) {
                state.last_status_code = returnCode;
                state.last_change_time = currentRunStr;
                pluginStatusChanged = "1";
            }

            state.last_result = {
                {"name", check.name},
                {"pluginName", check.description},
                {"pluginStatus", pluginStatus},
                {"pluginStatusCode", returnCode},
                {"pluginOutput", stdoutText},
                {"pluginStatusChanged", pluginStatusChanged},
                {"maintenance", check.maintenance},
                {"lastChange", state.last_change_time},
                {"lastRun", currentRunStr},
                {"nextRun", nextRunStr},
                {"labels", check.labels}
            };
        };

        // --------------------------------------------------------
        // Define reusable file writing logic using a Lambda
        // --------------------------------------------------------
        auto writeOutputFile = [&]() {
            json results = json::array();
            for (const auto& check : config.checks) {
                if (!stateMap[check.name].last_result.empty()) {
                    results.push_back(stateMap[check.name].last_result);
                }
            }

            SystemSnapshot snapshot = collect_snapshot();
            json output = {
                {"host", buildHostJson(config, snapshot)},
                {"monitoring", results}
            };

            //std::ofstream outputFile(config.outputFile);
	    //std::string outputPath = config.dataDir + "/" + config.outputFile;
	    //std::ofstream outputFile(outputPath);
	    //std::filesystem::path outputPath =
            //	std::filesystem::path(config.dataDir) / config.outputFile;

	    const auto outputPath = getOutputPath(config);

    	    std::ofstream outputFile(outputPath);

            if (!outputFile.is_open()) {
		logger.error("Could not open output file: " + outputPath.string());
                throw std::runtime_error("Could not open output file: " + outputPath.string());
            }
            outputFile << output.dump(2) << '\n';
        };
	if (config.usePush) {
		logger.info("Initiate push function");
        	const CURLcode curlResult = curl_global_init(CURL_GLOBAL_DEFAULT);

     		if (curlResult != CURLE_OK) {
        		std::cerr << "ERROR: curl_global_init failed: "
                  	          << curl_easy_strerror(curlResult) << '\n';
			logger.error (std::string("Failed to initialize curl: ") + curl_easy_strerror(curlResult));
        		return 1;
    		}
	}
	logger.info("Application initialized");
        // ========================================================
        // 1. STARTUP EXECUTION (Staggered by 4 seconds)
        // ========================================================
        //std::cout << "Starting ncpa2almond 0.9.1" << std::endl;
	std::this_thread::sleep_for(std::chrono::milliseconds(100));
	//std::cout << "Performing initial checks." << std::endl;
	logger.info("Performing initial checks");
        
        bool first_check = true;
        for (const auto& check : config.checks) {
            if (!g_running) break;

            if (!first_check && config.startupSleepSeconds > 0) {
                // Interruptible 4-second sleep between initial checks
                auto stagger_wake = std::chrono::steady_clock::now() + std::chrono::seconds(config.startupSleepSeconds);
                while (g_running && std::chrono::steady_clock::now() < stagger_wake) {
                    std::this_thread::sleep_for(std::chrono::milliseconds(200));
                }
            }
            if (!g_running) break;

            // Fetch fresh time exactly when this specific check runs
            auto now_steady = std::chrono::steady_clock::now();
            auto now_system = std::chrono::system_clock::now();
           
	    logger.info("Processing [" + check.name + "]"); 
            processCheck(check, stateMap[check.name], now_steady, now_system);
            first_check = false;
        }

        if (g_running) {
	    logger.info("Writing collected data to file: " + getOutputPath(config).string());
            writeOutputFile();
	    const auto json_file_name = getOutputPath(config);
	    const auto metrics_file = std::filesystem::path(config.dataDir) / "metrics" /  config.metricsFile;
	    if (generate_prometheus_file(json_file_name, metrics_file, config.metricsPrefix) == 0) {
		logger.info("Metrics file written to " + metrics_file.string());
	    }
	    else {
		    logger.warning("Could not write to metrics file '" + metrics_file.string());
	    }
        }

        // ========================================================
        // 2. ROLLING SCHEDULER LOOP
        // ========================================================
        if (g_running) {
            //std::cout << "Initialization complete." << std::endl;
	    logger.info ("Initialization complete.");
	    std::this_thread::sleep_for(std::chrono::milliseconds(100));
	    //std::cout << "Entering scheduler loop." << std::endl;
	    logger.info("Entering scheduler loop");
        }
        
        while (g_running) {
            // Find the time of the closest upcoming check
            auto now_steady = std::chrono::steady_clock::now();
            auto next_wake = now_steady + std::chrono::hours(1); 
            for (const auto& [name, state] : stateMap) {
                if (state.next_run_steady < next_wake) {
                    next_wake = state.next_run_steady;
                }
            }

            // Interruptible sleep loop: Checks `g_running` every 200ms
            while (g_running && std::chrono::steady_clock::now() < next_wake) {
                std::this_thread::sleep_for(std::chrono::milliseconds(200));
            }

            if (!g_running) break;

            now_steady = std::chrono::steady_clock::now();
            auto now_system = std::chrono::system_clock::now();
            bool file_needs_update = false;

            // Execute checks that are due
	    //std::cout << "Execute checks that are due" << std::endl;
	    logger.info("Will now execute checks that are due.");
            for (const auto& check : config.checks) {
                auto& state = stateMap[check.name];
                if (now_steady >= state.next_run_steady) {
		    logger.info("Processing check [" + check.name + "]");
                    processCheck(check, state, now_steady, now_system);
                    file_needs_update = true;
                }
            }

            // Update file only if a check actually ran
            if (file_needs_update) {
		//std::cout << "Update json file." << std::endl;
		logger.info ("Update json data file.");
                writeOutputFile();
		if (config.usePush) {
			if ((config.pushUrl != "None") && (config.pushPort > 0)) {
				// build push url and push
				std::string final_url = build_push_url(config.pushUrl, config.pushPort, "/api/v1/upload");
				//std::cout << "Pushing data to " << final_url << std::endl;
				logger.info("Try to push data to endpoint " + config.pushUrl);
				std::filesystem::path json_path = std::filesystem::path(config.dataDir) / config.outputFile;
				if (post_json_file_stream(final_url.c_str(), json_path.string().c_str()) == 0) {
					//std::cout << "Pushed data successfully!" << std::endl;
					logger.info("Data successfully pushed");
				}
				else {
					//std::cout << "WARN: Data push failed." << std::endl;
					logger.warning("Failed to push data to " + final_url);
				}
				std::this_thread::sleep_for(std::chrono::milliseconds(200));
				logger.info("Try to push metrics to endpoint " + config.pushUrl);
				std::filesystem::path metrics_path = std::filesystem::path(config.dataDir) / "metrics" / config.metricsFile;
				if (post_metrics_file_stream(final_url.c_str(), metrics_path.string().c_str()) == 0) {
					logger.info("Metrics successfully pushed");
				}
				else {
					logger.warning("Failed to push metrics to " + final_url);
				}
			}
			else {
				//std::cout << "WARN: Push config is enabled but not configurated correctly." << std::endl;
				logger.warning("Push config is enabled but not configurated properly. Can not push data.");
			}
		}
		//std::cout << "Update metrics file." << std::endl;
		logger.info("Update data metrics file.");
		const auto json_file_name = getOutputPath(config);
		const auto metrics_file = std::filesystem::path(config.dataDir) / "metrics" /  config.metricsFile;
		bool is_written = false;
		while (!is_written) {
			if (generate_prometheus_file(json_file_name, metrics_file, config.metricsPrefix) == 0) {
				//std::cout << "Writing metrics file." << std::endl;
				logger.info("Metrics file written to " + metrics_file.string());
				is_written = true;
				break;
			}
			std::this_thread::sleep_for(std::chrono::milliseconds(200));
			logger.info("Failed to write metrics file, due to lock. Will retry!");
		}
            }
        }

        // ========================================================
        // 3. GRACEFUL SHUTDOWN CLEANUP
        // ========================================================
        //std::cout << "\nShutting down gracefully..." << std::endl;
	logger.info ("Shutting down gracefully...");
	const auto outputPath = getOutputPath(config);
	if (config.removeFile) {
            //std::cout << "Removing output file: " << outputPath.string() << std::endl;
	    logger.info ("Removing output file: " + outputPath.string());
            
	    std::error_code ec;
	    if (!std::filesystem::remove(outputPath, ec)) {
        	if (ec) {
            		std::cerr << "Warning: Could not remove file "
                      		<< outputPath.string()
                      		<< ": " << ec.message() << '\n';
        	}
	    }
        }
	if (config.usePush) {
		logger.info ("Cleaning up push connections");
		curl_global_cleanup();
	}
	logger.info("ncpa2almond says goodbye (but want to startup again).");
    }
    catch (const std::exception& e) {
        std::cerr << "ERROR: " << e.what() << '\n';
        return 1;
    }

    return 0;
}
