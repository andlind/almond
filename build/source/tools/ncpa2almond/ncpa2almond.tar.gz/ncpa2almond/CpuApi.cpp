#include "CpuApi.hpp"

#include <curl/curl.h>

#include <stdexcept>
#include <string>

static size_t writeCallback(
    void* contents,
    size_t size,
    size_t nmemb,
    void* userp)
{
    const size_t totalSize = size * nmemb;

    auto* response = static_cast<std::string*>(userp);

    response->append(
        static_cast<char*>(contents),
        totalSize
    );

    return totalSize;
}

std::string getCpuData(const Config& config)
{
    CURL* curl = curl_easy_init();

    if (!curl) {
        throw std::runtime_error(
            "Failed to initialize libcurl"
        );
    }

    std::string response;

    // URL-encode the individual parameters.
    char* token = curl_easy_escape(
        curl,
        config.token.c_str(),
        0
    );

    char* aggregate = curl_easy_escape(
        curl,
        config.aggregate.c_str(),
        0
    );

    if (!token || !aggregate) {
        if (token)
            curl_free(token);

        if (aggregate)
            curl_free(aggregate);

        curl_easy_cleanup(curl);

        throw std::runtime_error(
            "Failed to URL-encode parameters"
        );
    }

    std::string url =
        config.url +
        "?token=" + token +
        "&check=" + std::to_string(config.check) +
        "&warning=" + std::to_string(config.warning) +
        "&critical=" + std::to_string(config.critical) +
        "&aggregate=" + aggregate +
	"&verify_tls=false";

    curl_free(token);
    curl_free(aggregate);

    curl_easy_setopt(
        curl,
        CURLOPT_URL,
        url.c_str()
    );

    curl_easy_setopt(
        curl,
        CURLOPT_WRITEFUNCTION,
        writeCallback
    );

    curl_easy_setopt(
        curl,
        CURLOPT_WRITEDATA,
        &response
    );

    // Equivalent to curl -k
    curl_easy_setopt(
        curl,
        CURLOPT_SSL_VERIFYPEER,
        0L
    );

    curl_easy_setopt(
        curl,
        CURLOPT_SSL_VERIFYHOST,
        0L
    );

    // Don't wait forever if the API isn't responding.
    curl_easy_setopt(
        curl,
        CURLOPT_CONNECTTIMEOUT,
        5L
    );

    curl_easy_setopt(
        curl,
        CURLOPT_TIMEOUT,
        10L
    );

    CURLcode result = curl_easy_perform(curl);

    if (result != CURLE_OK) {
        std::string error =
            curl_easy_strerror(result);

        curl_easy_cleanup(curl);

        throw std::runtime_error(
            "curl failed: " + error
        );
    }

    // Check HTTP status code.
    long httpStatus = 0;

    curl_easy_getinfo(
        curl,
        CURLINFO_RESPONSE_CODE,
        &httpStatus
    );

    curl_easy_cleanup(curl);

    if (httpStatus < 200 || httpStatus >= 300) {
        throw std::runtime_error(
            "API returned HTTP status " +
            std::to_string(httpStatus)
        );
    }

    return response;
}

