#pragma once

#include <filesystem>
#include <fstream>
#include <mutex>
#include <string>

class Logger
{
public:
    explicit Logger(const std::filesystem::path& logPath);
    ~Logger();

    // Non-copyable
    Logger(const Logger&) = delete;
    Logger& operator=(const Logger&) = delete;

    void info(const std::string& message);
    void warning(const std::string& message);
    void error(const std::string& message);

private:
    void write(const std::string& level,
               const std::string& message);

    std::ofstream logFile;
    std::mutex mutex;
};

