#include "ApiClient.hpp"

#include <curl/curl.h>

#include <stdexcept>
#include <string>


namespace {

size_t writeCallback(
    void* contents,
    size_t size,
    size_t nmemb,
    void* userp)
{
    size_t totalSize = size * nmemb;

    static_cast<std::string*>(userp)->append(
        static_cast<char*>(contents),
        totalSize
    );

    return totalSize;
}

} // namespace


std::string executeCheck(
    const CheckConfig& check,
    const std::string& baseUrl,
    const std::string& token,
    bool verifyTls)
{
    CURL* curl = curl_easy_init();

    if (!curl) {
        throw std::runtime_error(
            "Could not initialize CURL"
        );
    }


    // ------------------------------------------------------------
    // Build URL
    // ------------------------------------------------------------

    std::string url = baseUrl;

    // Avoid // between baseUrl and check.url
    if (!url.empty() && url.back() == '/' &&
        !check.url.empty() && check.url.front() == '/') {

        url.pop_back();
    }

    if (!check.url.empty() &&
        (url.empty() || url.back() != '/') &&
        check.url.front() != '/') {

        url += '/';
    }

    url += check.url;


    // ------------------------------------------------------------
    // Add NCPA query parameters
    // ------------------------------------------------------------

    url += "?token=" + token;
    url += "&check=" + std::to_string(check.check);
    url += "&warning=" + std::to_string(check.warning);
    url += "&critical=" + std::to_string(check.critical);


    // ------------------------------------------------------------
    // Response
    // ------------------------------------------------------------

    std::string response;


    // ------------------------------------------------------------
    // HTTP headers
    // ------------------------------------------------------------

    struct curl_slist* headers = nullptr;

    headers = curl_slist_append(
        headers,
        "Accept: application/json"
    );


    // ------------------------------------------------------------
    // CURL configuration
    // ------------------------------------------------------------

    curl_easy_setopt(
        curl,
        CURLOPT_URL,
        url.c_str()
    );

    curl_easy_setopt(
        curl,
        CURLOPT_HTTPHEADER,
        headers
    );

    curl_easy_setopt(
        curl,
        CURLOPT_WRITEFUNCTION,
        writeCallback
    );

    curl_easy_setopt(
        curl,
        CURLOPT_WRITEDATA,
        &response
    );


    // ------------------------------------------------------------
    // TLS verification
    // ------------------------------------------------------------

    curl_easy_setopt(
        curl,
        CURLOPT_SSL_VERIFYPEER,
        verifyTls ? 1L : 0L
    );

    curl_easy_setopt(
        curl,
        CURLOPT_SSL_VERIFYHOST,
        verifyTls ? 2L : 0L
    );


    // ------------------------------------------------------------
    // Perform request
    // ------------------------------------------------------------

    CURLcode res =
        curl_easy_perform(curl);


    if (res != CURLE_OK) {

        std::string error =
            curl_easy_strerror(res);

        curl_slist_free_all(headers);
        curl_easy_cleanup(curl);

        throw std::runtime_error(
            "CURL request failed: " + error
        );
    }


    // ------------------------------------------------------------
    // HTTP status
    // ------------------------------------------------------------

    long httpStatus = 0;

    curl_easy_getinfo(
        curl,
        CURLINFO_RESPONSE_CODE,
        &httpStatus
    );


    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);


    if (httpStatus < 200 || httpStatus >= 300) {

        throw std::runtime_error(
            "HTTP request failed with status " +
            std::to_string(httpStatus)
        );
    }


    return response;
}

