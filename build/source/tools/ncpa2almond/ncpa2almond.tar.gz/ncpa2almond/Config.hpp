#pragma once

#include <nlohmann/json.hpp>

#include <string>
#include <vector>

struct CheckConfig {
    std::string name;
    std::string description;

    std::string url;

    bool maintenance;
    int runInterval;

    int check;
    int warning;
    int critical;

    std::string aggregate;

    nlohmann::json labels;
};

struct Config {
    std::string outputFile;
    std::string host;

    std::string baseUrl;
    std::string token;

    std::string pushUrl;
    std::string dataDir;
    bool verifyTls;
    bool useCollect;
    bool usePush;
    bool removeFile;
    int pushPort;
    int startupSleepSeconds = 4;

    std::vector<CheckConfig> checks;
};

Config loadConfig(const std::string& filename);

