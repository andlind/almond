#pragma once

#include <nlohmann/json.hpp>

#include <string>
#include <vector>

struct CheckConfig {
    std::string name;
    std::string description;

    std::string url;

    bool maintenance;

    int check;
    int warning;
    int critical;

    std::string aggregate;

    nlohmann::json labels;
};

struct Config {
    std::string outputFile;
    std::string host;

    std::string baseUrl;
    std::string token;

    bool verifyTls;

    std::vector<CheckConfig> checks;
};

Config loadConfig(const std::string& filename);

