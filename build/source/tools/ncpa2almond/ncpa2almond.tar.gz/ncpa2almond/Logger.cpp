#include "Logger.h"

#include <chrono>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>

Logger::Logger(const std::filesystem::path& logPath)
{
    logFile.open(
        logPath,
        std::ios::out | std::ios::app
    );

    if (!logFile.is_open()) {
        throw std::runtime_error(
            "Could not open log file: " + logPath.string()
        );
    }
}

Logger::~Logger()
{
    if (logFile.is_open()) {
        logFile.close();
    }
}

void Logger::info(const std::string& message)
{
    write("INFO", message);
}

void Logger::warning(const std::string& message)
{
    write("WARNING", message);
}

void Logger::error(const std::string& message)
{
    write("ERROR", message);
}

void Logger::write(
    const std::string& level,
    const std::string& message)
{
    std::lock_guard<std::mutex> lock(mutex);

    // Get current time
    const auto now = std::chrono::system_clock::now();
    const std::time_t time =
        std::chrono::system_clock::to_time_t(now);

    std::tm localTime{};

#ifdef _WIN32
    localtime_s(&localTime, &time);
#else
    localtime_r(&time, &localTime);
#endif

    std::ostringstream timestamp;

    timestamp << std::put_time(
        &localTime,
        "%Y-%m-%d %H:%M:%S"
    );

    const std::string line =
        timestamp.str() +
        " [" +
        level +
        "] " +
        message;

    // Write to logfile
    logFile << line << std::endl;
    logFile.flush();

    // Also write to console
    if (level == "ERROR" || level == "WARNING") {
        std::cerr << line << std::endl;
    }
    else {
        std::cout << line << std::endl;
    }
}

