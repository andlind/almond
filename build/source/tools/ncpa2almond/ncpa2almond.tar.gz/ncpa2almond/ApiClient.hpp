#pragma once

#include "Config.hpp"

#include <string>


std::string executeCheck(
    const CheckConfig& check,
    const std::string& baseUrl,
    const std::string& token,
    bool verifyTls
);

