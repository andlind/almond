#ifndef MODKAFKA_H
#define MODKAFKA_H

int send_message_to_kafka(char*, char*, char*);
int send_ssl_message_to_kafka(char*, char*, char*, char*, char*, char*);

#endif // MODKAFKA_H 
