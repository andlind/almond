#ifndef ALMOND_ALERTING_H
#define ALMOND_ALERTING_H

#define ALMOND_ALERTING_CONFIG_PATH "/etc/almond/alerting.conf"
#define ALMOND_ALERTING_MAX_CHECKS 256

typedef struct {
    char *slack_webhook_url;
    char *smtp_url;
    char *smtp_username;
    char *smtp_password;
    char *email_from;
    char *email_recipient;
    char *email_subject;
    int enabled;
    int configured;
} AlertRoute;

typedef struct {
    int send_alerts_to_slack;
    int send_alerts_to_email;
    char *slack_webhook_url;
    char *smtp_url;
    char *smtp_username;
    char *smtp_password;
    char *email_from;
    char *email_recipient;
    char *email_subject;
    AlertRoute checks[ALMOND_ALERTING_MAX_CHECKS];
} AlertConfig;

struct PluginItem;

typedef struct {
    const char *host;
    const char *check_name;
    const char *state;
    const char *summary;
    const char *details;
    const char *timestamp;
} AlertDetails;

void alert_config_init(AlertConfig *config);
int alert_config_load(const char *path, AlertConfig *config);
void alert_config_free(AlertConfig *config);
int alert_notify_check(AlertConfig *config,
                       struct PluginItem *item,
                       const AlertDetails *alert,
                       int send_slack,
                       int send_email);

/* Return 0 on success and -1 on error. Configuration values are owned by AlertConfig. */
int alert_send_slack(const char *webhook_url, const AlertDetails *alert);
int alert_send_email(const char *smtp_url,
                     const char *username,
                     const char *password,
                     const char *from,
                     const char *recipient,
                     const char *subject,
                     const AlertDetails *alert);

#endif