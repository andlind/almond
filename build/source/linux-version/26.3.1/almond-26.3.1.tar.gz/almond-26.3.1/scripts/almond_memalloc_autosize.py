#!/usr/bin/env python3
"""Measure Almond plugin buffer sizes before starting Almond (Python 3.6+, Linux).

Examples (the preview ALSO RUNS the configured monitoring commands):
  python3 almond_memalloc_autosize.py --samples 3
  python3 almond_memalloc_autosize.py --samples 3 --apply --enable
  python3 almond_memalloc_autosize.py --static-only --plugins-conf ./plugins.conf

Run as the Almond service user, with the same environment and working directory.
Paths default to /etc/almond/plugins.conf, /opt/almond/plugins,
/opt/almond/memalloc.alm, and /etc/almond/memalloc.conf; override them if needed.
Only run this against trusted plugin declarations: commands use /bin/sh just
as Almond does. No shell command text or plugin output is printed or retained.

The six managed keys are PLUGINITEMNAME_SIZE, PLUGINITEMDESC_SIZE,
PLUGINITEMCMD_SIZE, PLUGINCOMMAND_SIZE, PLUGINOUTPUT_SIZE, PLUGINMESSAGE_SIZE.
Static sizes cover ALL declarations, including inactive ones. Output is sampled
from active=1 declarations unless --include-inactive is set. All stdout bytes
are counted, including line endings; stderr is drained but is not Almond data.
Exit codes 0..3 are valid monitoring results. A failed, empty, timed-out, binary,
or oversized sample prevents ALL changes. --static-only cannot write anything.

For names, descriptions and commands, the stored value is the measured byte
length (at least 1). Output uses max(64, ceil(observed * (1 + margin/100)) +
output_reserve), with 20% and 64 spare bytes by default. Almond getConstants()
already adds one byte; this script does not add another NUL byte to its values.
No sample can establish a future worst case: use representative load, more
samples, larger margins, or --grow-only to retain existing larger values.

Other memalloc entries are preserved, with backups and atomic replacement on
--apply. --enable additionally writes 'enabled' to memalloc.conf, with backup.
Restart Almond afterwards; existing allocations cannot be resized this way.

The accompanying plugins.c uses getline() for complete declaration lines and
exact-length allocation for name/description/command. Install and rebuild it
before using declarations longer than the old 1024-byte reader could handle.
The supplied run_plugin() stores the last non-empty output line; a larger
buffer does not make Almond combine multi-line plugin output.
"""

import argparse
import datetime
import math
import os
from pathlib import Path
import re
import selectors
import signal
import stat
import subprocess
import sys
import tempfile
import time
from collections import namedtuple


Plugin = namedtuple("Plugin", "name description command active line")
KEYS = ("PLUGINITEMNAME_SIZE", "PLUGINITEMDESC_SIZE", "PLUGINITEMCMD_SIZE",
        "PLUGINCOMMAND_SIZE", "PLUGINOUTPUT_SIZE", "PLUGINMESSAGE_SIZE")
INT_MAX_MINUS_ONE = 2147483646  # getConstants() currently reads a signed C int.


def byte_length(value):
    return len(value.encode("utf-8"))


def read_plugins(path):
    plugins = []
    with path.open("r", encoding="utf-8", newline="") as source:
        for number, raw in enumerate(source, 1):
            if not raw.strip() or raw.lstrip().startswith("#"):
                continue
            if "\0" in raw:
                raise ValueError("{}:{}: NUL byte in declaration".format(path, number))
            match = re.fullmatch(r"\[([^\]]+)\] *(.*)", raw.rstrip("\r\n"))
            if not match:
                raise ValueError("{}:{}: expected [name] description;command;active;interval".format(
                    path, number))
            # Match C strtok's literal semicolon splitting; do not interpret
            # shell quotes or JSON labels as an alternative declaration format.
            fields = match.group(2).split(";")
            if len(fields) < 4 or any(not field for field in fields[:4]):
                raise ValueError("{}:{}: incomplete declaration".format(path, number))
            description, command, active, interval = fields[:4]
            if not re.fullmatch(r"\s*[+-]?\d+\s*", active):
                raise ValueError("{}:{}: active must be an integer; semicolons "
                                 "inside commands are not supported by Almond".format(path, number))
            if not re.fullmatch(r"\s*[+-]?\d+\s*", interval.split("{", 1)[0]):
                raise ValueError("{}:{}: invalid interval".format(path, number))
            plugins.append(Plugin(match.group(1), description, command, int(active), number))
    if not plugins:
        raise ValueError("no plugin declarations found in {}".format(path))
    return plugins


def read_optional(path):
    try:
        return path.read_bytes()
    except FileNotFoundError:
        return None


def parse_memalloc(original):
    text = (original or b"").decode("utf-8")
    values = {}
    for number, row in enumerate(text.splitlines(), 1):
        if not row.strip():
            continue
        match = re.fullmatch(r"\s*([A-Z][A-Z0-9_]*)\s+([0-9]+)\s*", row)
        if not match:
            raise ValueError("memalloc row {}: expected KEY positive_integer; "
                             "Almond's fscanf reader does not accept comments".format(number))
        key, value = match.group(1), int(match.group(2))
        if byte_length(key) > 49 or not 1 <= value <= INT_MAX_MINUS_ONE:
            raise ValueError("memalloc row {}: key or value outside C reader limits".format(number))
        if key in values:
            raise ValueError("duplicate memalloc key: {}".format(key))
        values[key] = value
    if len(values) > 50:
        raise ValueError("memalloc.alm exceeds the C reader's MAX_CONSTANTS=50")
    return text, values


def full_command(plugin_dir, plugin):
    # Deliberately match snprintf(cmd, ..., "%s/%s", pluginDir, item->command).
    # Do not shlex.split(), re-quote, or substitute a different executable.
    return str(plugin_dir) + "/" + plugin.command


def measure(command, timeout, max_output, cwd):
    started = time.monotonic()
    proc = subprocess.Popen(command, shell=True, executable="/bin/sh",
                            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, start_new_session=True,
                            cwd=cwd, bufsize=0)
    selector = selectors.DefaultSelector()
    selector.register(proc.stdout, selectors.EVENT_READ, "stdout")
    selector.register(proc.stderr, selectors.EVENT_READ, "stderr")
    counts = {"stdout": 0, "stderr": 0}
    problem = None
    try:
        while selector.get_map() or proc.poll() is None:
            remaining = timeout - (time.monotonic() - started)
            if remaining <= 0:
                problem = "timed out after {} seconds".format(timeout)
                break
            if not selector.get_map():
                try:
                    proc.wait(timeout=remaining)
                except subprocess.TimeoutExpired:
                    problem = "timed out after {} seconds".format(timeout)
                break
            for key, _ in selector.select(min(remaining, 0.2)):
                data = os.read(key.fd, 65536)
                if not data:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                counts[key.data] += len(data)
                if key.data == "stdout":
                    if b"\0" in data:
                        problem = "NUL byte in stdout; Almond expects text"
                    if counts["stdout"] > max_output:
                        problem = "stdout exceeded --max-output-bytes={} (sample incomplete)".format(
                            max_output)
                if problem:
                    break
            if problem:
                break
        if problem:
            raise ValueError(problem)
        rc = proc.wait()
        if rc not in (0, 1, 2, 3):
            raise ValueError("exit code {} is not a monitoring status (0..3); "
                             "{} stderr bytes".format(rc, counts["stderr"]))
        if counts["stdout"] == 0:
            raise ValueError("empty stdout (exit {}, {} stderr bytes); cannot size output".format(
                rc, counts["stderr"]))
        return counts["stdout"], counts["stderr"], rc
    except BaseException:
        # The shell and its descendants share this new process group. Kill all
        # of them, including descendants still holding the capture pipes open.
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        proc.wait()
        raise
    finally:
        selector.close()
        proc.stdout.close()
        proc.stderr.close()


def render_memalloc(text, proposed):
    remaining = dict(proposed)
    lines = []
    for row in text.splitlines(keepends=True):
        match = re.match(r"(\s*)([A-Z][A-Z0-9_]*)(\s+)([0-9]+)(.*)", row.rstrip("\r\n"))
        if match and match.group(2) in remaining:
            key = match.group(2)
            ending = row[len(row.rstrip("\r\n")):]
            row = "{}{}{}{}{}{}".format(match.group(1), key, match.group(3),
                                         remaining.pop(key), match.group(5), ending)
        lines.append(row)
    result = "".join(lines)
    if remaining and result and not result.endswith(("\n", "\r")):
        result += "\n"
    result += "".join("{} {}\n".format(key, value) for key, value in remaining.items())
    parse_memalloc(result.encode("utf-8"))  # Includes MAX_CONSTANTS check after appends.
    return result.encode("utf-8")


def atomic_write(path, content, original):
    # Resolve an existing symlink so the link itself survives replacement.
    path = path.resolve()
    if read_optional(path) != original:
        raise ValueError("{} changed during sampling; run again".format(path))
    if content == original:
        print("Unchanged: {}".format(path))
        return
    info = path.stat() if original is not None else None
    if info and not stat.S_ISREG(info.st_mode):
        raise ValueError("not a regular file: {}".format(path))
    descriptor, temporary = tempfile.mkstemp(prefix="." + path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(descriptor, "wb") as target:
            if info and (info.st_uid != os.geteuid() or info.st_gid != os.getegid()):
                os.fchown(target.fileno(), info.st_uid, info.st_gid)
            os.fchmod(target.fileno(), stat.S_IMODE(info.st_mode) if info else 0o644)
            target.write(content)
            target.flush()
            os.fsync(target.fileno())
        if read_optional(path) != original:
            raise ValueError("{} changed before writing; run again".format(path))
        if original is not None:
            stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
            backup = path.with_name(path.name + ".bak." + stamp + "." + str(os.getpid()))
            with backup.open("xb") as target:
                os.fchmod(target.fileno(), stat.S_IMODE(info.st_mode))
                target.write(original)
                target.flush()
                os.fsync(target.fileno())
            print("Backup: {}".format(backup))
        os.replace(temporary, str(path))
        print("Updated: {}".format(path))
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def arguments(argv):
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--plugins-conf", type=Path, default=Path("/etc/almond/plugins.conf"))
    parser.add_argument("--plugin-dir", default="/opt/almond/plugins",
                        help="exact plugins.directory value from almond.conf")
    parser.add_argument("--memalloc", type=Path, default=Path("/opt/almond/memalloc.alm"))
    parser.add_argument("--enable-conf", type=Path, default=Path("/etc/almond/memalloc.conf"))
    parser.add_argument("--cwd", type=Path, help="working directory for plugin commands; default: current")
    parser.add_argument("--samples", type=int, default=1, help="runs per selected plugin (default: 1)")
    parser.add_argument("--timeout", type=float, default=30, help="seconds per run (default: 30)")
    parser.add_argument("--margin-percent", type=float, default=20, help="output headroom (default: 20)")
    parser.add_argument("--output-reserve", type=int, default=64, help="extra output bytes (default: 64)")
    parser.add_argument("--max-output-bytes", type=int, default=1048576,
                        help="stop a run above this stdout limit (default: 1048576)")
    parser.add_argument("--include-inactive", action="store_true", help="also execute inactive plugins")
    parser.add_argument("--grow-only", action="store_true", help="retain any larger existing managed size")
    parser.add_argument("--static-only", action="store_true", help="preview static sizes without running plugins")
    parser.add_argument("--apply", action="store_true", help="back up and update memalloc.alm")
    parser.add_argument("--enable", action="store_true", help="also enable memalloc.conf; requires --apply")
    args = parser.parse_args(argv)
    if args.samples < 1 or not math.isfinite(args.timeout) or args.timeout <= 0:
        parser.error("--samples and --timeout must be positive")
    if not math.isfinite(args.margin_percent) or args.margin_percent < 0 or args.output_reserve < 0:
        parser.error("margin and reserve must be finite and non-negative")
    if not 1 <= args.max_output_bytes <= INT_MAX_MINUS_ONE:
        parser.error("invalid output limit")
    if args.enable and not args.apply:
        parser.error("--enable requires --apply")
    if args.static_only and args.apply:
        parser.error("--static-only is preview-only; it cannot be used with --apply")
    return args


def main(argv=None):
    args = arguments(argv)
    plugins = read_plugins(args.plugins_conf)
    original = read_optional(args.memalloc)
    text, existing = parse_memalloc(original)
    enable_original = read_optional(args.enable_conf) if args.enable else None
    if args.enable and args.enable_conf.resolve() == args.memalloc.resolve():
        raise ValueError("--enable-conf and --memalloc must be different files")
    measured = dict(zip(KEYS[:4], (
        max(byte_length(p.name) for p in plugins),
        max(byte_length(p.description) for p in plugins),
        max(byte_length(p.command) for p in plugins),
        max(byte_length(full_command(args.plugin_dir, p)) for p in plugins))))
    selected = [p for p in plugins if p.active == 1 or args.include_inactive]
    failures = []
    largest_output = 0
    if not args.static_only:
        if not selected:
            raise ValueError("no active plugins to sample; use --include-inactive if appropriate")
        print("Executing {} plugins, {} sample(s) each; stdout measured in bytes.".format(
            len(selected), args.samples), flush=True)
        for plugin in selected:
            for sample in range(1, args.samples + 1):
                label = "{!r} [{}/{}]".format(plugin.name, sample, args.samples)
                print("Sampling {} ...".format(label), flush=True)
                try:
                    output, errors, rc = measure(full_command(args.plugin_dir, plugin),
                                                  args.timeout, args.max_output_bytes, args.cwd)
                    largest_output = max(largest_output, output)
                    print("  stdout={} bytes; stderr={} bytes; exit={}".format(output, errors, rc), flush=True)
                except (OSError, ValueError) as error:
                    failures.append(label + ": " + str(error))
                    print("  FAILED: {}".format(error), flush=True)
        if failures:
            raise ValueError("{} incomplete sample(s); no files written. Fix failed "
                             "commands/environment or adjust the timeout/limit, then rerun.".format(len(failures)))
        measured["PLUGINOUTPUT_SIZE"] = largest_output
        measured["PLUGINMESSAGE_SIZE"] = largest_output
    proposed = {key: max(1, value) for key, value in measured.items()}
    if not args.static_only:
        capacity = max(64, math.ceil(largest_output * (1 + args.margin_percent / 100)) + args.output_reserve)
        proposed["PLUGINOUTPUT_SIZE"] = capacity
        proposed["PLUGINMESSAGE_SIZE"] = capacity
    if args.grow_only:
        proposed = {key: max(value, existing.get(key, 0)) for key, value in proposed.items()}
    if any(value > INT_MAX_MINUS_ONE for value in proposed.values()):
        raise ValueError("a proposed size exceeds the C reader's signed int limit")
    updated = render_memalloc(text, proposed)
    print("\n{:<24} {:>12} {:>12} {:>12}".format("Key", "Measured", "Existing", "Proposed"))
    for key in KEYS:
        if key in proposed:
            print("{:<24} {:>12} {:>12} {:>12}".format(
                key, measured[key], existing.get(key, "default"), proposed[key]))
    print("\nOther memalloc keys are preserved. Stored sizes exclude Almond's added NUL byte.")
    if len(selected) < len(plugins):
        print("Inactive plugins were included in static sizes but were not executed.")
    if args.static_only:
        print("Static preview only: output sizes were not measured; no commands executed or files written.")
    elif not args.apply:
        print("Preview only: commands ran, but no files were written. Use --apply to save; --enable to activate.")
    else:
        # Refuse to overwrite a declaration file through a mistaken CLI path.
        protected = {args.plugins_conf.resolve()}
        if args.memalloc.resolve() in protected or (args.enable and args.enable_conf.resolve() in protected):
            raise ValueError("output paths must not overwrite plugins.conf")
        atomic_write(args.memalloc, updated, original)
        if args.enable:
            atomic_write(args.enable_conf, b"enabled\n", enable_original)
        print("Restart Almond to use these sizes. Output headroom covers samples, not every future state.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nInterrupted; current command group stopped.", file=sys.stderr)
        sys.exit(130)
    except (OSError, ValueError, OverflowError) as error:
        print("ERROR: {}".format(error), file=sys.stderr)
        sys.exit(1)
