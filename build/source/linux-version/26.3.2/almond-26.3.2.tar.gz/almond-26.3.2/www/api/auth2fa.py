"""Password-first TOTP login with shared, encrypted pending challenges."""
import contextlib
import fcntl
import hmac
import io
import json
import logging
import os
import re
import secrets
import socket
import sqlite3
import stat
import tempfile
import time

import pyotp
import qrcode
from cryptography.fernet import Fernet, InvalidToken
from flask import (
    Blueprint, abort, current_app, redirect, render_template,
    request, send_file, session, url_for,
)
from werkzeug.security import check_password_hash
from api.login_handler import create_session, handle_local_login

logger = logging.getLogger(__name__)
auth_blueprint = Blueprint('auth', __name__)
logon_img = '/static/almond.png'
admin_user_file = '/etc/almond/users.conf'
auth_user_file = '/etc/almond/auth2fa.enc'
CHALLENGE_TTL = 300
MAX_ATTEMPTS = 5


def _enabled():
    return str(current_app.config.get('AUTH_TYPE', '')).lower() == '2fa'


def _require_mode():
    if not _enabled():
        abort(403, description='Application two-factor authentication is disabled.')
    secret = current_app.secret_key
    if not secret or secret == 'BAD_SECRET_KEY' or len(secret) < 32:
        abort(503, description='Configure a persistent, random HOWRU_SECRET_KEY of at least 32 characters.')
    if str(current_app.config.get('AUTH2FA_P', 'false')).lower() not in ('true', '1', 'yes', 'on'):
        abort(503, description='Enable api.persistent2fa=true for shared two-factor authentication.')
    load_key()


def load_key():
    key = os.environ.get('HOWRU_FERNET_KEY')
    if not key:
        abort(503, description='Configure the same persistent HOWRU_FERNET_KEY for every worker.')
    try:
        encoded = key.encode('ascii')
        Fernet(encoded)
        return encoded
    except (ValueError, UnicodeError):
        abort(503, description='HOWRU_FERNET_KEY is not a valid Fernet key.')


def _cipher():
    return Fernet(load_key())


def encrypt_data(data, fernet):
    return fernet.encrypt(data)


def decrypt_data(token, fernet):
    return fernet.decrypt(token)


def _secret_path(filepath=None):
    return filepath or current_app.config.get('AUTH2FA_SECRET_FILE', auth_user_file)


def _read_secrets(path):
    try:
        with open(path, 'rb') as source:
            encrypted = source.read()
    except FileNotFoundError:
        return {}
    except OSError:
        logger.exception('Could not read the encrypted 2FA file.')
        abort(503, description='Could not read the two-factor enrollment file.')
    if not encrypted:
        return {}
    try:
        records = json.loads(_cipher().decrypt(encrypted).decode('utf-8'))
        if not isinstance(records, dict):
            raise ValueError('Unexpected enrollment file structure')
        if records.get('format') == 'howru-auth2fa-v2':
            records = records.get('users')
            if not isinstance(records, dict) or any(not isinstance(v, str) for v in records.values()):
                raise ValueError('Unexpected enrollment file structure')
            return records
        # Existing files used a plain username -> secret mapping for local users.
        if any(not isinstance(v, str) for v in records.values()):
            raise ValueError('Unexpected enrollment file structure')
        return {_principal({'username': name, 'provider': 'local'}): value
                for name, value in records.items()}
    except (InvalidToken, UnicodeError, ValueError, TypeError):
        logger.error('Could not decrypt the 2FA file; leaving its contents unchanged.')
        abort(503, description='Could not decrypt existing enrollments. Check HOWRU_FERNET_KEY; the file has not been overwritten.')


def load_user_secret(username, filepath=None, *, provider='local'):
    principal = _principal({'username': username, 'provider': provider})
    return _read_secrets(_secret_path(filepath)).get(principal)


def _secret_for(user):
    return load_user_secret(user['username'], provider=user.get('provider') or 'local')


def save_user_secret(username, secret, filepath=None, *, provider='local'):
    """Create an enrollment atomically; never replace an existing user's secret."""
    principal = _principal({'username': username, 'provider': provider})
    path = _secret_path(filepath)
    directory = os.path.dirname(os.path.abspath(path))
    try:
        fd = os.open(path + '.lock', os.O_CREAT | os.O_RDWR, 0o600)
        with os.fdopen(fd, 'a+b') as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            records = _read_secrets(path)
            if principal in records:
                return hmac.compare_digest(records[principal], secret)
            records[principal] = secret
            stored = {'format': 'howru-auth2fa-v2', 'users': records}
            encrypted = _cipher().encrypt(json.dumps(stored).encode('utf-8'))
            temporary = None
            try:
                fd, temporary = tempfile.mkstemp(prefix='.auth2fa-', dir=directory)
                with os.fdopen(fd, 'wb') as target:
                    target.write(encrypted)
                    target.flush()
                    os.fsync(target.fileno())
                os.chmod(temporary, stat.S_IRUSR | stat.S_IWUSR)
                os.replace(temporary, path)
                temporary = None
            finally:
                if temporary:
                    os.unlink(temporary)
        return True
    except OSError:
        logger.exception('Could not save the encrypted 2FA enrollment.')
        abort(503, description='Could not save the two-factor enrollment file.')


@contextlib.contextmanager
def _database():
    path = current_app.config.get('AUTH2FA_STATE_FILE', '/etc/almond/auth2fa-state.sqlite3')
    try:
        fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
        os.close(fd)
        os.chmod(path, 0o600)
        connection = sqlite3.connect(path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.executescript('''
            CREATE TABLE IF NOT EXISTS challenges (
                id TEXT PRIMARY KEY, payload BLOB NOT NULL,
                expires REAL NOT NULL, attempts INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS otp_usage (
                principal TEXT PRIMARY KEY, last_counter INTEGER NOT NULL DEFAULT -1,
                failures INTEGER NOT NULL DEFAULT 0, locked_until REAL NOT NULL DEFAULT 0
            );
        ''')
        try:
            yield connection
            connection.commit()
        except BaseException:
            connection.rollback()
            raise
        finally:
            connection.close()
    except (OSError, sqlite3.Error):
        logger.exception('Could not access the shared 2FA challenge store.')
        abort(503, description='Could not access the shared two-factor login store.')


def _principal(user):
    provider = str(user.get('provider') or 'local').lower()
    username = user['username']
    return json.dumps([provider, username], ensure_ascii=True, separators=(',', ':'))


def _payload(row):
    try:
        return json.loads(_cipher().decrypt(bytes(row['payload'])).decode('utf-8'))
    except (InvalidToken, ValueError, UnicodeError):
        abort(503, description='Could not read the pending two-factor login. Check the shared encryption key.')


def begin_two_factor_login(user, tokens=None):
    """Called only after the password/provider has verified the first factor."""
    _require_mode()
    if not isinstance(user, dict) or not user.get('username'):
        abort(400, description='No verified user was supplied.')
    challenge = secrets.token_urlsafe(32)
    state = {'user': user, 'tokens': tokens, 'setup_secret': None}
    encrypted = _cipher().encrypt(json.dumps(state).encode('utf-8'))
    with _database() as db:
        db.execute('DELETE FROM challenges WHERE expires < ?', (time.time(),))
        db.execute('INSERT INTO challenges (id,payload,expires) VALUES (?,?,?)',
                   (challenge, encrypted, time.time() + CHALLENGE_TTL))
    session.clear()
    session['pending_2fa'] = challenge
    session['2fa_csrf'] = secrets.token_urlsafe(32)
    return False


def _pending():
    challenge = session.get('pending_2fa')
    if not challenge:
        return None
    with _database() as db:
        row = db.execute('SELECT * FROM challenges WHERE id=?', (challenge,)).fetchone()
    if not row or row['expires'] <= time.time() or row['attempts'] >= MAX_ATTEMPTS:
        session.clear()
        return None
    return row, _payload(row)


def _need_pending(username=None):
    _require_mode()
    pending = _pending()
    if not pending:
        abort(403, description='Sign in with your password or identity provider before setting up or verifying 2FA.')
    if username is not None and pending[1]['user']['username'] != username:
        abort(403, description='You can only enroll your own signed-in account.')
    return pending


def _issuer():
    return current_app.config.get('AUTH2FA_ISSUER') or 'howru-' + socket.gethostname()


def _local_identity(username, password):
    path = current_app.config.get('AUTH2FA_USERS_FILE', admin_user_file)
    record = None
    try:
        with open(path, 'r') as source:
            for line in source:
                if not line.strip():
                    continue
                try:
                    entries = json.loads(line)
                except ValueError:
                    continue
                if isinstance(entries, dict) and username in entries:
                    record = entries[username]
    except OSError:
        logger.exception('Could not read local user credentials.')
        return None
    if isinstance(record, str):
        password_hash, roles = record, ['admin']  # Existing legacy-user behavior.
    elif isinstance(record, dict):
        password_hash = record.get('password') or record.get('hash')
        roles = record.get('roles') or []
        if not isinstance(roles, list):
            return None
    else:
        return None
    if not isinstance(password_hash, str):
        return None
    try:
        valid = check_password_hash(password_hash, password)
    except (ValueError, TypeError):
        valid = False
    return handle_local_login(username, roles) if valid else None


def verify_password(username, password):
    return _local_identity(username, password) is not None


def generate_qr_code(data):
    return qrcode.make(data)


@auth_blueprint.after_request
def _private_response(response):
    response.headers['Cache-Control'] = 'no-store'
    response.headers['Pragma'] = 'no-cache'
    return response


@auth_blueprint.route('/almond/admin/login', methods=['GET', 'POST'])
def login():
    _require_mode()
    if request.method == 'POST':
        session.clear()
        username = (request.form.get('uname') or '').strip()
        password = request.form.get('psw') or ''
        user = _local_identity(username, password)
        if user is None:
            return 'Invalid username or password', 401
        create_session(user)
        return redirect(url_for('auth.verify_2fa'))
    return render_template('login_fa.html', logon_image=logon_img)


@auth_blueprint.route('/almond/admin/enable_2fa/<username>')
def enable_2fa(username):
    row, state = _need_pending(username)
    principal = _principal(state['user'])
    if _secret_for(state['user']):
        return 'Two-factor authentication is already enrolled. This URL cannot reset it.', 409
    if not state.get('setup_secret'):
        state['setup_secret'] = pyotp.random_base32()
        encrypted = _cipher().encrypt(json.dumps(state).encode('utf-8'))
        with _database() as db:
            db.execute('BEGIN IMMEDIATE')
            current = db.execute('SELECT * FROM challenges WHERE id=?', (row['id'],)).fetchone()
            if not current or current['expires'] <= time.time():
                abort(403, description='The pending login expired. Sign in again.')
            # Reuse an already-created setup secret if another request won the race.
            saved_state = _payload(current)
            if saved_state.get('setup_secret'):
                state = saved_state
            else:
                db.execute('UPDATE challenges SET payload=? WHERE id=?', (encrypted, row['id']))
    return render_template(
        '_two_factor_setup.html', username=username, issuer=_issuer(),
        user_secret=state['setup_secret'], logon_image=logon_img,
    )


@auth_blueprint.route('/almond/admin/qr_code/<username>')
def qr_code(username):
    _, state = _need_pending(username)
    if _secret_for(state['user']):
        return 'Enrollment is already complete; the secret is not displayed again.', 409
    secret = state.get('setup_secret')
    if not secret:
        return 'Start two-factor enrollment first.', 404
    uri = pyotp.TOTP(secret).provisioning_uri(name=username, issuer_name=_issuer())
    buf = io.BytesIO()
    generate_qr_code(uri).save(buf, format='PNG')
    buf.seek(0)
    return send_file(buf, mimetype='image/png')


def _matched_counter(secret, token):
    if not re.fullmatch(r'[0-9]{6}', token):
        return None
    totp = pyotp.TOTP(secret)
    counter = int(time.time()) // totp.interval
    for offset in (0, -1, 1):
        candidate = counter + offset
        if candidate >= 0 and hmac.compare_digest(totp.at(candidate * totp.interval), token):
            return candidate
    return None


@auth_blueprint.route('/verify_2fa', methods=['GET', 'POST'])
def verify_2fa():
    _require_mode()
    pending = _pending()
    if not pending:
        return redirect(url_for('auth.login'))
    row, state = pending
    user = state['user']
    principal = _principal(user)
    secret = _secret_for(user)
    if request.method == 'GET':
        if not secret and not state.get('setup_secret'):
            return redirect(url_for('auth.enable_2fa', username=user['username']))
        return render_template(
            '_two_factor_verify.html', logon_image=logon_img,
            username=user['username'], csrf_token=session.get('2fa_csrf', ''),
        )
    supplied_csrf = request.form.get('csrf_token') or ''
    expected_csrf = session.get('2fa_csrf') or ''
    if not supplied_csrf or not expected_csrf or not hmac.compare_digest(supplied_csrf, expected_csrf):
        abort(400, description='Invalid verification form. Reload the verification page.')
    token = (request.form.get('token') or '').strip()
    failure = None
    # One transaction serializes attempts, replay checks, and consuming a challenge.
    with _database() as db:
        db.execute('BEGIN IMMEDIATE')
        current = db.execute('SELECT * FROM challenges WHERE id=?', (row['id'],)).fetchone()
        if not current or current['expires'] <= time.time() or current['attempts'] >= MAX_ATTEMPTS:
            failure = ('The pending login expired. Sign in again.', 401)
        else:
            state = _payload(current)
            user = state['user']
            principal = _principal(user)
            secret = _secret_for(user)
            setup_secret = state.get('setup_secret')
            usage = db.execute('SELECT * FROM otp_usage WHERE principal=?', (principal,)).fetchone()
            if usage and usage['locked_until'] > time.time():
                failure = ('Too many verification attempts. Try again in five minutes.', 429)
            else:
                if secret and setup_secret and not hmac.compare_digest(secret, setup_secret):
                    failure = ('This account was enrolled by another login. Sign in again.', 409)
                else:
                    candidate_secret = secret or setup_secret
                    counter = _matched_counter(candidate_secret, token) if candidate_secret else None
                    if counter is None or (usage and counter <= usage['last_counter']):
                        failures = 1
                        if usage and not usage['locked_until']:
                            failures += usage['failures']
                        locked_until = time.time() + CHALLENGE_TTL if failures >= MAX_ATTEMPTS else 0
                        db.execute('''INSERT INTO otp_usage(principal,last_counter,failures,locked_until)
                            VALUES (?, -1, ?, ?) ON CONFLICT(principal) DO UPDATE SET
                            failures=excluded.failures,locked_until=excluded.locked_until''',
                            (principal, failures, locked_until))
                        db.execute('UPDATE challenges SET attempts=attempts+1 WHERE id=?', (row['id'],))
                        failure = (('Too many verification attempts. Try again in five minutes.', 429)
                                   if locked_until else ('Invalid or already-used 2FA token.', 401))
                    elif not secret and not save_user_secret(user['username'], candidate_secret, provider=user.get('provider') or 'local'):
                        failure = ('Enrollment already exists. Sign in again.', 409)
                    else:
                        db.execute('''INSERT INTO otp_usage(principal,last_counter,failures,locked_until)
                            VALUES (?, ?, 0, 0) ON CONFLICT(principal) DO UPDATE SET
                            last_counter=excluded.last_counter,failures=0,locked_until=0''', (principal, counter))
                        db.execute('DELETE FROM challenges WHERE id=?', (row['id'],))
    if failure:
        return failure
    create_session(user, state.get('tokens'), two_factor_verified=True)
    return redirect('/almond/admin')


@auth_blueprint.route('/protected')
def protected():
    from api.login_handler import is_logged_in
    if not is_logged_in() or not session.get('authenticated'):
        return redirect(url_for('auth.login'))
    return 'This is a protected page accessible only to fully authenticated users.'
