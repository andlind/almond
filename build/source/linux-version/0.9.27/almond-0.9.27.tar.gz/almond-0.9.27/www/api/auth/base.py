class AuthProvider:
    def authenticate(self, **kwargs):
        raise NotImplementedError

    def get_userinfo(self, token):
        raise NotImplementedError
