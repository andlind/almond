from .oauth_code import OAuthCodeFlow
import os

provider = OAuthCodeFlow(
    auth_url=os.getenv("PROVIDER_AUTH_URL"),
    token_url=os.getenv("PROVIDER_TOKEN_URL"),
    client_id=os.getenv("KEYCLOAK_CLIENT_ID"),
    client_secret=os.getenv("KEYCLOAK_CLIENT_SECRET"),
    redirect_uri=os.getenv("PROVIDER_REDIRECT_URI")
)
