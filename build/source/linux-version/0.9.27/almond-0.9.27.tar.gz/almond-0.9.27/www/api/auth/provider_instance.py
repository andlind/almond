from .oauth_code import OAuthCodeFlow
import os

provider = OAuthCodeFlow(
    auth_url="http://localhost:8089/realms/almondmonitor/protocol/openid-connect/auth",
    token_url="http://host.docker.internal:8089/realms/almondmonitor/protocol/openid-connect/token",
    client_id=os.getenv("KEYCLOAK_CLIENT_ID"),
    client_secret=os.getenv("KEYCLOAK_CLIENT_SECRET"),
    redirect_uri="http://localhost:8015/callback"
)
