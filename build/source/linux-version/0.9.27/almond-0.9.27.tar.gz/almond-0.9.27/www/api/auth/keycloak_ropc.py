import requests
from .base import AuthProvider

class KeycloakROPC(AuthProvider):
    def __init__(self, token_url, client_id, client_secret):
        self.token_url = token_url
        self.client_id = client_id
        self.client_secret = client_secret

    def authenticate(self, username, password):
        data = {
            "grant_type": "password",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "username": username,
            "password": password
        }

        resp = requests.post(self.token_url, data=data)
        #print("Status:", resp.status_code)
        #print("Body:", resp.text)
        if resp.status_code == 200:
            return resp.json()

        return None

    def get_userinfo(self, token):
        return {}
