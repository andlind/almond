class AuthService:
    def __init__(self, provider):
        self.provider = provider

    def login(self, **kwargs):
        try:
            token_data = self.provider.authenticate(**kwargs)
        except Exception as e:
            print ("Provider authentication failed:" , e)
            return None
        if not token_data:
            return None

        return {
            "access_token": token_data.get("access_token"),
            "refresh_token": token_data.get("refresh_token"),
            "expires_in": token_data.get("expires_in"),
            "provider": self.provider.__class__.__name__
        }
