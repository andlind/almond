#define _XOPEN_SOURCE 700
#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <netdb.h>
#include <time.h>
#include <pthread.h>
#include <signal.h>
#include <math.h>
#include <sys/stat.h>
#include <sys/types.h>

int parse_line(char *buf) {
	printf("%s\n", buf);
	int i;
	int x;
	int y;
	int s_count = 0;
	int p_count = 0;
	for (i = 0; i < 1000; i++) {
		if (buf[i] == '\n')
			break;
		if (buf[i] == ';')
			s_count++;
		if (buf[i] == '[' || buf[i] == ']')
			p_count++;
	}
	i = 0;
	char *p = strtok(buf, ";");
	char *array[4];
	while (p != NULL) {
		array[i++] = p;
		p = strtok(NULL, ";");
	}
	sscanf(array[2], "%d", &x);
	if (x == 0 || x == 1) {
		 y = atoi(array[3]);
		 if (!(y > 0)) {
			 return 2;
		 }
	}
	else
		return 2;
	if (s_count == 3 && p_count == 2)
		return 0;
	else
		return 2;
}

int main() {
	FILE * fPtr = NULL;
        char * filename = NULL;

        char buffer[1000];
        char enable[30] = "scheduler.quickStart=1";
        char disable[30] = "scheduler.quickStart=0";
        filename = "/etc/almond/plugins.conf";

        fPtr = fopen(filename, "r");

        if (fPtr == NULL) {
                exit(EXIT_SUCCESS);
        }

	int i;
        while ((fgets(buffer, 1000, fPtr)) != NULL){
		//printf("%s\n", buffer);
                /*char *pch = strstr(buffer, "quickStart");
                if (pch) {
                        if (on > 0)
                                fputs(enable, fTemp);
                        else
                                fputs(disable, fTemp);
                        fputs("\n", fTemp);
                }
                else
                        fputs(buffer, fTemp);*/
		for(i = 0; i < 1000; i++) {
			if (buffer[i] == '#') 
				break;
			else {
				if (parse_line(buffer) > 0) {
					return 2;
				}
				break;
			}
		}	
        }
        fclose(fPtr);
        fPtr = NULL;
        return 0;
}
