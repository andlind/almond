#ifndef VERSION_H
#define VERSION_H

#define VERSION "0.9.24"

#endif
