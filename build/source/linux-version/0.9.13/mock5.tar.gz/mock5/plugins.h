#ifndef ALMOND_PLUGINS_H
#define ALMOND_PLUGINS_H

#include "data.h"

// global config
extern char* pluginDeclarationFile;
extern size_t g_plugin_count;
extern PluginItem *g_plugins;
extern int decCount;

int countDeclarations(char *file_name);
// main entry point
//void init_plugins(const char *, size_t *);
int init_plugins();
void updatePluginDeclarations();
size_t getPluginCount();
PluginItem *getPluginItem(size_t index);

#endif // ALMOND_PLUGINS_H
