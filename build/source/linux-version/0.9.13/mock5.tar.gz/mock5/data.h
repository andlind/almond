#ifndef ALMOND_DATA_STRUCTURES_HEADER
#define ALMOND_DATA_STRUCTURES_HEADER

#define TIMESTAMP_SIZE 64
#include <time.h>
#include <stdbool.h>

typedef struct PluginItem {
    char   *name;
    char   *description;
    char   *command;                // use "command" consistently
    char    lastRunTimestamp[TIMESTAMP_SIZE];
    char    nextRunTimestamp[TIMESTAMP_SIZE];
    char    lastChangeTimestamp[TIMESTAMP_SIZE];
    char    statusChanged[2];
    int     active;
    int     interval;
    int     id;
    time_t  nextRun;
} PluginItem;

#endif // ALMOND_DATA_STRUCTURES_HEADER
