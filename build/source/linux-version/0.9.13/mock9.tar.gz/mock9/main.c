#define _GNU_SOURCE
#define _XOPEN_SOURCE 700
#define _DEFAULT_SOURCE
#ifndef VERSION
#define VERSION "0.9.13"
#endif
#include <stdio.h>  // Put stdio.h first
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <ctype.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include "data.h"
#include "plugins.h"
#include "uthash.h"

#define MAX_PLUGINS 256
#define TIME_BUF_LEN 80
#define CMD_BUF_SIZE      1024
#define LINE_BUF_SIZE     1024
#define TIMESTAMP_SIZE     64

char* pluginDeclarationFile = NULL;
char* pluginDir = NULL;
char* pluginReturnString = NULL;
int decCount;
int enableKafkaExport = 0;
int pluginResultToFile = 0;
int enableTimeTuner = 0;
int timeScheduler = 0;
int logPluginOutput = 0;
size_t plugindir_size = 50;
size_t plugincommand_size = 100;
size_t pluginmessage_size = 2300;
size_t pluginoutput_size = 1500;
time_t tPluginFile;
int g_plugin_count = 0;
PluginItem **g_plugins   = NULL;
PluginItem *g_plugin_map   = NULL; // hash map by name
Scheduler *scheduler = NULL;
static pid_t plugin_pid_set[MAX_PLUGINS];
static pthread_mutex_t plugin_set_mtx = PTHREAD_MUTEX_INITIALIZER;
unsigned int volatile thread_counter = 0;
unsigned short *threadIds = NULL;
pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;

char *trim(char *s) {
    char *ptr;
    if (!s)
        return NULL;   // NULL string
    if (!*s)
        return s;      // empty string
    for (ptr = s + strlen(s) - 1; (ptr >= s) && isspace(*ptr); --ptr);
    ptr[1] = '\0';
    return s;
}

static int cmp_plugin_by_id(const void *a, const void *b) {
    const PluginItem *pa = *(const PluginItem * const *)a;
    const PluginItem *pb = *(const PluginItem * const *)b;
    return pa->id - pb->id;
}

int checkPluginFileStat(const char *path, time_t oldMTime, int set) {
        struct stat file_stat;
        int err = stat(path, &file_stat);
        if (err != 0) {
                perror(" [file_is_modified] stat");
                exit(errno);
        }
        tPluginFile = file_stat.st_mtime;
        if (set > 0)
                return 0;
        else
                return file_stat.st_mtime > oldMTime;
}

void add_plugin_pid(pid_t pid) {
        pthread_mutex_lock(&plugin_set_mtx);
        for (int i = 0; i < MAX_PLUGINS; i++) {
                if (plugin_pid_set[i] == 0) { plugin_pid_set[i] = pid; break; }
        }
        pthread_mutex_unlock(&plugin_set_mtx);
}

void remove_plugin_pid(pid_t pid) {
        pthread_mutex_lock(&plugin_set_mtx);
        for (int i = 0; i < MAX_PLUGINS; i++) {
                if (plugin_pid_set[i] == pid) { plugin_pid_set[i] = 0; break; }
        }
        pthread_mutex_unlock(&plugin_set_mtx);
}

int is_plugin_pid(pid_t pid) {
        int found = 0;
        pthread_mutex_lock(&plugin_set_mtx);
        for (int i = 0; i < MAX_PLUGINS; i++) {
                if (plugin_pid_set[i] == pid) { found = 1; break; }
        }
        pthread_mutex_unlock(&plugin_set_mtx);
        return found;
}

TrackedPopen tracked_popen(const char *cmd) {
        int pfd[2];
        if (pipe(pfd) == -1) { perror("pipe"); return (TrackedPopen){NULL, -1}; }

        pid_t pid = fork();
        if (pid < 0) {
                perror("fork");
                close(pfd[0]); close(pfd[1]);
                return (TrackedPopen){NULL, -1};
        }
        if (pid == 0) {
                // child
                close(pfd[0]);
                dup2(pfd[1], STDOUT_FILENO);
                close(pfd[1]);
                execl("/bin/sh", "sh", "-c", cmd, (char*)NULL);
                _exit(127);
        }

        close(pfd[1]);
        FILE *fp = fdopen(pfd[0], "r");
        return (TrackedPopen){fp, pid};
}

int tracked_pclose(TrackedPopen *tp) {
        /*int status = -1, rc = -1;
        if (tp->fp) {
                fclose(tp->fp);
                rc = waitpid(tp->pid, &status, 0);
                if (rc == tp->pid) {
                        if (WIFEXITED(status)) return WEXITSTATUS(status);
                        else return -1;
                }
        }
        return -1;*/
        if (!tp || !tp->fp) return -1;
        fclose(tp->fp);
        int status, rc;
        do {
                rc = waitpid(tp->pid, &status, 0);
        } while (rc == -1 && errno == EINTR);
        if (rc == -1) {
                return -1;
        }
        if (WIFEXITED(status))
                return WEXITSTATUS(status);
        else if (WIFSIGNALED(status))
                return 128 + WTERMSIG(status);
        else 
                return -1;
}

void* pluginExeThread(void* data) {
        intptr_t storeIndex = (intptr_t)data;
        pthread_detach(pthread_self());
        // VERBOSE printf("Executing %s in pthread %lu\n", g_plugins[storeIndex].description, pthread_self());
        pthread_mutex_lock(&mtx);
        threadIds[(short)storeIndex] = 1;
        PluginItem *pi = getPluginItem(storeIndex);
        run_plugin(pi);
        /*if (timeScheduler == 1){
                rescheduleChecks();
        }*/
        thread_counter--;
        pthread_mutex_unlock(&mtx);
        threadIds[(short)storeIndex] = 0;
        pthread_exit(NULL);
}

void run_plugin(PluginItem *item) {
    if (!item) return;

    /* 1) Save old return code and start timers */
    int    prevRet = item->output.retCode;
    clock_t start  = clock();
    time_t  now    = time(NULL);

    /* 2) Build full plugin command */
    char cmd[CMD_BUF_SIZE];
    snprintf(cmd, CMD_BUF_SIZE, "%s/%s", pluginDir, item->command);
    printf("Running: %s\n", cmd);

    /* 3) Spawn process and capture last non-empty line */
    TrackedPopen tp = tracked_popen(cmd);
    if (!tp.fp) {
        perror("tracked_popen");
        item->output.retCode = -1;
    }
    else {
        add_plugin_pid(tp.pid);

        char *last_line = NULL;
        char  buf[LINE_BUF_SIZE];

        while (fgets(buf, sizeof buf, tp.fp)) {
            char *t = trim(buf);
            if (*t) {
                free(last_line);
                last_line = strdup(t);
            }
        }
        int rc = tracked_pclose(&tp);
        remove_plugin_pid(tp.pid);

        /* 4) Map shell exit codes to our retCode */
        if      (rc == 126)           item->output.retCode = 0;
        else if (rc == 256)           item->output.retCode = 1;
        else if (rc == 512)           item->output.retCode = 2;
        else                          item->output.retCode = rc;

        /* 5) Safely replace retString, capped at pluginoutput_size */
        free(item->output.retString);
        item->output.retString = NULL;

        if (last_line) {
            size_t len = strlen(last_line);
            if (len >= (size_t)pluginoutput_size) {
                len = pluginoutput_size - 1;
            }
            item->output.retString = malloc(len + 1);
            if (item->output.retString) {
                memcpy(item->output.retString, last_line, len);
                item->output.retString[len] = '\0';
            }
            free(last_line);
        }
    }
    /* 6) Format current timestamp */
    char ts_now[TIMESTAMP_SIZE];
    struct tm tm_now;
    localtime_r(&now, &tm_now);
    strftime(ts_now, sizeof ts_now, "%Y-%m-%d %H:%M:%S", &tm_now);

    /* 7) Update statusChanged and lastChangeTimestamp */
    if (prevRet != item->output.retCode) {
        /* statusChanged is a char[2] array */
        memcpy(item->statusChanged, "1", 2);
        strncpy(item->lastChangeTimestamp,
                ts_now,
                sizeof item->lastChangeTimestamp - 1);
        item->lastChangeTimestamp[sizeof item->lastChangeTimestamp - 1] = '\0';
    }
    else {
        memcpy(item->statusChanged, "0", 2);
    }

    /* 8) Update lastRunTimestamp */
    strncpy(item->lastRunTimestamp,
            ts_now,
            sizeof item->lastRunTimestamp - 1);
    item->lastRunTimestamp[sizeof item->lastRunTimestamp - 1] = '\0';

    /* 9) Compute and store nextRunTimestamp */
    time_t next = now + (item->interval * 60);
    struct tm tm_next;
    localtime_r(&next, &tm_next);
    strftime(item->nextRunTimestamp,
             sizeof item->nextRunTimestamp,
             "%Y-%m-%d %H:%M:%S",
             &tm_next);
    item->nextRun = next;

    /* 10) Save prevRetCode for next iteration */
    item->output.prevRetCode = prevRet;

    /* 11) Print elapsed time */
    double ms = (double)(clock() - start) * 1000.0 / CLOCKS_PER_SEC;
    printf("%s executed in %.0f ms (ret=%d)\n\n",
           item->name,
           ms,
           item->output.retCode);
}

void execute_all_plugins(void) {
    for (int i = 0; i < g_plugin_count; ++i) {
        PluginItem *item = g_plugins[i];
        if (item && item->active) {
            run_plugin(item);
        }
    }
}

/*void runPlugin(int storeIndex) {
        char ch = '/';
        int prevRetCode = 0;
        clock_t ct;
        time_t t;
        char currTime[TIME_BUF_LEN];
        int rc = 0;
        char sPluginCommand[plugincommand_size];

        prevRetCode = g_outputs[storeIndex].retCode;
        ct = clock();
        time(&t);
        snprintf(sPluginCommand, plugincommand_size, "%s%c", pluginDir, ch);
        strcat(sPluginCommand, g_plugins[storeIndex].command);
        //snprintf(infostr, infostr_size, "Running: %s.", g_plugins[storeIndex].command);
        //writeLog(trim(infostr), 0, 0);
        printf("Running: %s.\n", g_plugins[storeIndex].command);
        TrackedPopen tp = tracked_popen(sPluginCommand);
        if (tp.fp == NULL) {
                printf("Failed to run command\n");
                //writeLog("Failed to run comman via tracked_popen().", 2, 0);
                rc = -1;
        }
        else {
                add_plugin_pid(tp.pid);
                while (fgets(pluginReturnString, pluginmessage_size, tp.fp) != NULL) {
                        // VERBOSE  printf("%s", pluginReturnString);
                        printf("DEBUG: %s\n", pluginReturnString);
                }
                rc = tracked_pclose(&tp);
                if (rc == -1) {
                        //snprintf(infostr, infostr_size, "[runPlugin] tracked_pclose failed with errno %d (%s)", errno, strerror(errno));
                        //writeLog(trim(infostr), 1, 0);
			printf("[runPlugin] tracked_pclose failed with errno %d (%s)", errno, strerror(errno));
                }
                remove_plugin_pid(tp.pid);
        }
        if (rc > 0) {
                if (rc == 126)
			g_outputs[storeIndex].retCode = 0;
        	if (rc == 256)
                	g_outputs[storeIndex].retCode = 1;
       		else if (rc == 512)
                	g_outputs[storeIndex].retCode = 2;
                else
                	g_outputs[storeIndex].retCode = rc;
        }
        //outout.retString size?
        if (pluginReturnString != NULL) {
                if (g_outputs[storeIndex].retString == NULL) {
			g_outputs[storeIndex].retString =  malloc(pluginoutput_size);
		}
        	if (strlen(trim(pluginReturnString)) < pluginoutput_size)
        		strncpy(g_outputs[storeIndex].retString, trim(pluginReturnString), pluginoutput_size);
        	else {
        		pluginReturnString[pluginoutput_size] = '\0';
        		strncpy(g_outputs[storeIndex].retString, trim(pluginReturnString), pluginoutput_size);
        	}
        }
        size_t dest_size = 20;
        time_t tTime = time(NULL);
	struct tm tm = *localtime(&tTime);
        int len = snprintf(currTime, dest_size, "%04d-%02d-%02d %02d:%02d:%02d", tm.tm_year + 1900, tm.tm_mon +1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
        if (len >= dest_size) {
                //writeLog("Possible truncation of timestamp while running plugin.", 1, 0);
		printf("Possible truncation of timestamp while running plugin.\n");
        }
        if (g_outputs[storeIndex].prevRetCode != -1){
        	if (prevRetCode != g_outputs[storeIndex].retCode){
                	strcpy(g_plugins[storeIndex].statusChanged, "1");
                        strcpy(g_plugins[storeIndex].lastChangeTimestamp, currTime);
                }
                else {
                	strcpy(g_plugins[storeIndex].statusChanged, "0");
          	}
                if (enableTimeTuner == 1) {
			printf("No time tuner in this mock.\n");*/
                	/*if (storeIndex == timeTunerMaster) {
                        	timeTunerCounter++;
                               	if (timeTunerCounter == timeTunerCycle) {
                                	timeTunerCounter = 0;
                                        char oldTime[20];
                                        struct tm time;
                                        strcpy(oldTime, g_plugins[timeTunerMaster].lastRunTimestamp);
                                        strptime(oldTime, "%04d-%02d-%02d %02d:%02d:%02d", &time);
                                        time_t ttOldTime = 0, ttCurTime = 0;
                                        int year = 0, month = 0, day = 0, hour = 0, minute = 0, second = 0;
                                        if (sscanf(oldTime, "%04d-%02d-%02d %02d:%02d:%02d", &year, &month, &day, &hour, &minute, &second) == 6) {
                                        	struct tm breakdown = {0};
                                                breakdown.tm_year = year + 1900;
                                                breakdown.tm_mon = month - 1;
                                                breakdown.tm_mday = day;
                                                breakdown.tm_hour = hour;
                                                breakdown.tm_min = minute;
                                                breakdown.tm_sec = second;

                                                if ((ttOldTime = mktime(&breakdown)) == (time_t)-1) {
 							fprintf(stderr, "Could not convert time input to time_t\n");
                                                }
                                  	}
                                        if (sscanf(currTime, "%04d-%02d-%02d %02d:%02d:%02d", &year, &month, &day, &hour, &minute, &second) == 6) {
                                        	struct tm breakdown = {0};
                                                breakdown.tm_year = year + 1900;
                                                breakdown.tm_mon = month - 1;
                                                breakdown.tm_mday = day;
                                                breakdown.tm_hour = hour;
                                                breakdown.tm_min = minute;
                                                breakdown.tm_sec = second;
                                                if ((ttCurTime = mktime(&breakdown)) == (time_t)-1) {
                                                	fprintf(stderr, "Could not convert time input to time_t\n");
                                                }
                                   	}
                                        int difference = ttCurTime - ttOldTime - (g_plugins[timeTunerMaster].interval * 60);
                                        timeTune(difference);
                                }
                        }*/
        	/*}
                strcpy(g_plugins[storeIndex].lastRunTimestamp, currTime);
                time_t nextTime = t + (g_plugins[storeIndex].interval * 60);
                struct tm tNextTime;
                memset(&tNextTime, '\0', sizeof(struct tm));
                localtime_r(&nextTime, &tNextTime);
                len = snprintf(g_plugins[storeIndex].nextRunTimestamp, dest_size, "%04d-%02d-%02d %02d:%02d:%02d", tNextTime.tm_year + 1900, tNextTime.tm_mon +1, tNextTime.tm_mday, tNextTime.tm_hour, tNextTime.tm_min, tNextTime.tm_sec);
                if (len >= dest_size) {
                	//writeLog("Possible truncation of timestamp in 'runPlugin'.", 1, 0);
			printf("Possible truncation of timestamp in runPlugin\n");
                }
                g_plugins[storeIndex].nextRun = nextTime;
                g_outputs[storeIndex].prevRetCode = g_outputs[storeIndex].retCode;
                if (timeScheduler == 1) {
                	//scheduler[0].timestamp = nextTime;
                }
       	}
       	else {
       		g_outputs[storeIndex].prevRetCode = 0;
       	}
	//snprintf(infostr, infostr_size, "%s executed. Execution took %.0f milliseconds.\n", g_plugins[storeIndex].name, (double)ct);
        //writeLog(trim(infostr), 0, 0);
	printf("%s executed. Execution took %.0f milliseconds.\n", g_plugins[storeIndex].name, (double)ct);
        if (logPluginOutput == 1) {
                char* o_info;
                int o_info_size = pluginmessage_size + 195;
                o_info = malloc((size_t)o_info_size * sizeof(char));
                if (o_info == NULL) {
                        //writeLog("Could not allocate memory for variable 'o_info'.", 2, 0);
			printf("Could not allocate memory for o_info\n");
                }
                //snprintf(o_info, (size_t)o_info_size, "%s : %s", g_plugins[storeIndex].name, pluginReturnString);
                //writeLog(trim(o_info), 0, 0);
                printf("%s : %s\n", g_plugins[storeIndex].name, pluginReturnString);
                free(o_info);
                o_info = NULL;
        }
        if (pluginResultToFile == 1) {
                //writePluginResultToFile(storeIndex, update);
		printf("No plugin result file in this mock.\n");
        }
        if (enableKafkaExport == 1) {
        	// writeToKafkaTopic(storeIndex, update);
		printf("No Kafka export in this mock.\n");
        }
}*/

int countDeclarations(char *file_name) {
        FILE *fp = NULL;
        int i = 0;
        int ch;

        if (file_name == NULL || strlen(file_name) == 0) {
                //writeLog("Filename is not initialized or is empty.", 2, 0);
                fprintf(stderr, "Filename is uninitialized or empty.\n");
        }
        fp = fopen(file_name, "r");
        if (fp == NULL)
        {
                perror("Error while opening the file[countDeclarations].\n");
                //writeLog("Error opening and counting declarations file.", 2, 0);
                exit(EXIT_FAILURE);
        }
        while ((ch = fgetc(fp)) != EOF) {
                if (ch == '\n')
                        i++;
        }
        fclose(fp);
        fp = NULL;
        return i-1;
}

void runPluginThreads(int loopVal){
        char currTime[TIME_BUF_LEN];
        pthread_t thread_id;
        int rc;
        int i;
        time_t t = time(NULL);
        struct tm tm = *localtime(&t);

        snprintf(currTime, sizeof(currTime), "%04d-%02d-%02d %02d:%02d:%02d", tm.tm_year + 1900, tm.tm_mon +1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);

        /*if (timeScheduler == 1) {
                i = 1;
                struct Scheduler do_run = scheduler[0];
                while(i > 0) {
                        if ((t >= do_run.timestamp) && (g_plugins[do_run.id].active == 1)) {
                                //printf("DEBUG: startPluginThread id %d\n", do_run.id);
                                startPluginThread(do_run.id);
                                tspr++;
                        }
                        if (do_run.timestamp > t) {
                                //printf("Exit..\n");
                                break;
                        }
                        do_run = scheduler[0];
                }
                return;
        }*/

        for (i = 0; i < loopVal; i++) {
           long j = i;
           if (g_plugins[i]->active == 1) {
                if (t > g_plugins[i]->nextRun)
                {
                        rc = pthread_create(&thread_id, NULL, pluginExeThread, (void *)j);
                        if(rc) {
                                //snprintf(infostr, infostr_size, "Error: return code from phtread_create is %d\n", rc);
                                //writeLog(trim(infostr), 2, 0);
 				printf("Error: return code from pthread_create is %d.\n");
                        }
                        else {
                                //snprintf(infostr, infostr_size, "Created new thread (%lu) for plugin %s\n", thread_id, g_plugins[i].name);
                                //writeLog(trim(infostr), 0, 0);
				printf("Created new thread (%lu) for plugin %s.\n", thread_id, g_plugins[i]->name);
                                pthread_mutex_lock(&mtx);
                                thread_counter++;
                                pthread_mutex_unlock(&mtx);
                                //pthread_join(thread_id, NULL);
                        }
                }
            }
        }
        //pthread_exit(NULL);
}

void show_commands_sorted(void) {
    size_t total = g_plugin_count;
    if (total == 0) {
        puts("No plugins loaded.");
        return;
    }

    /* 1) Gather active plugins into a temp array */
    PluginItem **list = malloc(total * sizeof *list);
    if (!list) {
        perror("malloc");
        return;
    }

    size_t n = 0;
    for (size_t i = 0; i < total; i++) {
        PluginItem *pi = g_plugins[i];
        if (pi && pi->active) {
            list[n++] = pi;
        }
    }

    if (n == 0) {
        puts("No active plugins.");
        free(list);
        return;
    }
    qsort(list, n, sizeof *list, cmp_plugin_by_id);
    for (size_t i = 0; i < n; i++) {
        PluginItem *pi = list[i];
        printf("#%2d  %-20s : %s\n", 
               pi->id, pi->name, pi->description);
        printf("   Command     : %s\n", pi->command);
        printf("   Next run at : %s\n\n", pi->nextRunTimestamp);
    }

    free(list);
}

/*void show_commands_sorted() {
    size_t total = getPluginCount();
    PluginItem **list = malloc(total * sizeof *list);
    if (!list) return;
    
    size_t n = 0;
    for (size_t i = 0; i < total; i++) {
        PluginItem *pi = getPluginItem(i);
        if (pi && pi->active) {
            list[n++] = pi;
        }
    }

    for (size_t i = 0; i < n; i++) {
         printf("Pre-sort: id=%d name=%s\n", list[i]->id, list[i]->name);
    } 

    qsort(list, n, sizeof *list, cmp_plugin_by_id);

    for (size_t i = 0; i < n; i++) {
        PluginItem *pi = list[i];
        printf("# %d %s: %s\n", pi->id, pi->name, pi->description);
        printf("%s\n\n", pi->command);
        printf("Next run time: %s\n", pi->nextRunTimestamp);
    }

    free(list);
}

void show_commands() {
	size_t count = getPluginCount();
	for (size_t i = 0; i < count; i++) { 
		PluginItem *pi = getPluginItem(i);
		if (!pi) continue;
		if (!pi->active) continue;
		printf("# %s: %s\n", pi->name, pi->description);
        	printf("%s\n\n", pi->command);
	}
}*/

/*void free_declarations(PluginItem **arr, size_t count) {
    if (!arr) return;
    
    // Free each individual PluginItem array
    for (size_t i = 0; i < count; i++) {
        if (arr[i]) {
            PluginItem *current_array = arr[i];
            //size_t array_size =  somehow determine size of current_array ;
            
            for (size_t j = 0; j < array_size; j++) {
                if (current_array[j].name)
                    free(current_array[j].name);
                if (current_array[j].description)
                    free(current_array[j].description);
                if (current_array[j].command)
                    free(current_array[j].command);
            }
            free(current_array);
        }
    }
    free(arr);
}*/

/*void plugin_output_init(PluginOutput *o) {
        if (!o) return;
        o->retCode     = 0;
        o->prevRetCode = 0;
        o->retString   = NULL;
}*/

static void free_plugin_item(PluginItem *item) {
    if (!item) return;

    HASH_DEL(g_plugin_map, item);

    free(item->name);
    free(item->description);
    free(item->command);

    free(item->output.retString);

    free(item);
}

void free_all_plugins(void) {
    PluginItem *item, *tmp;

    HASH_ITER(hh, g_plugin_map, item, tmp) {
        free_plugin_item(item);
    }
    g_plugin_map = NULL;

    free(g_plugins);
    g_plugins       = NULL;
    g_plugin_count  = 0;
}

void destroy_mutexes() {
        pthread_mutex_destroy(&mtx);
        //pthread_mutex_destroy(&update_mtx);
        //destroy_log_mutex();
}

int main(void) {
    pluginDeclarationFile = malloc(20);
    snprintf(pluginDeclarationFile, 20, "%s", "plugins.conf"); 
    pluginDir = malloc(plugindir_size);
    snprintf(pluginDir, plugindir_size, "%s", "/opt/almond/plugins");
    printf("Debug pluginDir = %s\n", pluginDir);
    pluginReturnString = malloc((size_t)pluginmessage_size * sizeof(char));
    decCount = countDeclarations(pluginDeclarationFile);
    if (decCount <= 0) {
	printf("No valid plugins.conf file found. Is it empty?");
	return decCount;
    }
    //threadIds = (unsigned short*)malloc((size_t)decCount * sizeof(unsigned short));
    threadIds = (unsigned short*)malloc((size_t)MAX_PLUGINS * sizeof(unsigned short));
    memset(threadIds, 0, MAX_PLUGINS * sizeof(unsigned short));
    for (int i = 0; i < decCount; i++) {
    	threadIds[i] = 0;
    }
    thread_counter++;
    size_t plugin_count = (size_t)decCount;
    checkPluginFileStat(pluginDeclarationFile, tPluginFile, 0);
    //init_plugins(pluginDeclarationFile, &plugin_count);
    //init_plugins(pluginDeclarationFile);
    printf("DEBUG Dec_count = %d\n", decCount);
    if (init_plugins() != 0) {
	printf("Failed to initialize plugins.");
	return 1;
    }
    show_commands_sorted();
    // init scheduler execute all plugins
    execute_all_plugins();
    int run = 0; 
    while(run < 15) {
	if (checkPluginFileStat(pluginDeclarationFile, tPluginFile, 0)) {
        	//writeLog("Detected change of plugins file.", 0, 0);
              	//flushLog();
		printf("Detected change of plugins file.");
            	//updatePluginDeclarations();
                update_plugins();
		printf("Plugins updated. Total live plugins: %zu\n", g_plugin_count);
        }
	show_commands_sorted();
        /*for (int i = 0; i < decCount; i++) {
		PluginItem *pi = getPluginItem(i);
		if (pi && pi->active && pi->nextRunTimestamp == NULL) {
			printf("Need to run\n");
			//runPlugin(i);
		}
                else {
			printf("DEBUG Always run.\n");
			//runPlugin(i);
		}
	}*/
        runPluginThreads(decCount);
	printf("Sleeping...\n");
	printf("*****************************************************************\n");
	sleep(30);
	run++;
    }
    printf ("SHOW CURENT OUTPUTS ----->\n");
    for (int i = 0; i < decCount; ++i) {
        PluginItem *item = g_plugins[i];
        if (!item) continue;

        const char *outstr = item->output.retString
                             ? item->output.retString
                             : "";

        printf("%s = %d %d %s\n",
               item->name,
               item->output.retCode,
               item->output.prevRetCode,
               outstr);
    }
    free_all_plugins();
    free(pluginDeclarationFile);
    free(pluginDir);
    destroy_mutexes();
    pluginDeclarationFile = NULL;
    pluginDir = NULL;
    return 0;
}
