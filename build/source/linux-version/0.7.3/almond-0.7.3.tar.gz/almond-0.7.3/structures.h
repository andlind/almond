#ifndef ALMOND_DATA_STRUCTURES_HEADER
#define ALMOND_DATA_STRUCTURES_HEADER

#define PLUGINITEMNAME_SIZE 50
#define PLUGINITEMDESC_SIZE 100
#define PLUGINITEMCMD_SIZE 255
#define PLUGINOUTPUT_SIZE 1500

typedef struct PluginItem {
        char name[PLUGINITEMNAME_SIZE];
        char description[PLUGINITEMDESC_SIZE];
        char command[PLUGINITEMCMD_SIZE];
        char lastRunTimestamp[20];
        char nextRunTimestamp[20];
        char lastChangeTimestamp[20];
        char statusChanged[1];
        int active;
        int interval;
        int id;
        time_t nextRun;
} PluginItem;

typedef struct PluginOutput {
        int retCode;
        int prevRetCode;
        char retString[PLUGINOUTPUT_SIZE];
} PluginOutput;

#endif

