apk add --no-cache build-base
apk add --no-cache libjwt-devel
apk add --no-cache zlib-dev json-c-dev openssl-dev
apk add --no-cache libjwt-dev
apk add --no-cache curl-dev
ln -sf /usr/lib/libjwt.so.2.10.2 /usr/lib/libjwt.so
gcc -g -Wall main_s.c api_s.c config.c collect.c jwt_validate.c logger.c plugins.c heal.c alerting.c -std=c99 -O0 -pthread -fstack-protector -ljwt -ljson-c -lssl -lcrypto -lz -lcurl -o almond
