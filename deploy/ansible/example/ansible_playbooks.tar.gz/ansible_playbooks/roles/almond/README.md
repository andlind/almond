# Almond
*Built using template role 0.2*

Using the Almond package, primarily used as quick fix for obtaining issues with kafka cluster health to mimir

<< Add link to almond>>

## Changelog

v 0.1 only support for kafka checks

## Subtask explained

## Requirement

- used with opentelemetry and prometheus exporter to be useful
- run as root for current checks
- Need to set `kafka_cloud_data_cluster_name` per kafka group!

## About

Almond can combine regular nagios agent structure and  

## Howto use



## Copy this folder

Copy this file and rename it to `desiredrolename`

### Create the playbook

For example `desiredrolename.yml`

```
- name: Test the epic role desiredrolename
  hosts: [all|<group>] # <-- what hosts to limit it to
  become: true
  roles: 
#  - role: other epic roles to include before?   
   - role: desiredrolename
#  - role: other epic roles to include after?   
``` 

### Execute!

Then run it `ansible-playbook <desiredrolename> -i environments/lab/<inventoryfile> -l <limit_further>`

### Version 0.1

Simple templaterole does not contain anything specific just some base structure
