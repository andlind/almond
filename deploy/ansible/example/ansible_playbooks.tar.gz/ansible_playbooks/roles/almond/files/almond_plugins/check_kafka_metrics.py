#!/usr/bin/python3
import subprocess
import sys

return_value = 0
return_message = ""
leaderless_partitions = 0
under_replicated_partitions = 0
leaders = []
leaders_cmd = ["""/usr/bin/kafka-topics --zookeeper localhost:2181/confluent --describe | grep "Leader" | awk '{ print $6}'"""]
partitions_cmd = ["""/usr/bin/kafka-topics --zookeeper localhost:2181/confluent --under-replicated-partitions --describe"""]
try:
    leaders = subprocess.check_output(leaders_cmd,shell=True).decode("utf-8")
except subprocess.CalledProcessError as e:
    print(f"UNKOWN: Command failed with return code {e.returncode}")
    sys.exit(3)
for leader in leaders:
    if (leader == "None" or leader == "-1"):
        leaderless_partitions += 1
        return_value = 2
partitions = subprocess.getstatusoutput(partitions_cmd)
for x in partitions[1].split('\n'):
    under_replicated_partitions += 1
under_replicated_partitions -= 1
if (under_replicated_partitions != 0):
    return_value += 1
if return_value > 0:
    if return_value == 1:
        print("CRITICAL: Underreplicated partitions: " + str(under_replicated_partitions) + " | under_replicated_partitions=" + str(under_replicated_partitions) + " leaderless_partitions=" + str(leaderless_partitions))
    elif return_value == 2:
        print("CRITICAL: Leaderless partitions found. | under_replicated_partitions=" + str(under_replicated_partitions) + " leaderless_partitions=" + str(leaderless_partitions))
    else:
        print("CRITICAL: Kafka has underreplicated partitions and leaderless partitions. | under_replicated_partitions=" + str(under_replicated_partitions) + " leaderless_partitions=" + str(leaderless_partitions))
    sys.exit(2)
else:
    print("OK: Kafka metrics is fine | under_replicated_partitions=" + str(under_replicated_partitions) + " leaderless_partitions=" + str(leaderless_partitions))
sys.exit(0)
