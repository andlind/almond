#!/usr/bin/python3
import subprocess
import sys
import time

return_value = 3
return_message = ""
collect_metrics = " |"
count = 0
zk_version = "3.4.14"
zk_avg_latency = -1
zk_max_latency = -1
zk_min_latency = -1
zk_packets_received	= -1
zk_packets_sent	= -1
zk_num_alive_connections = -1
zk_outstanding_requests	= -1
zk_server_state	= "follower"
zk_znode_count = -1
zk_watch_count = -1
zk_ephemerals_count	= -1
zk_approximate_data_size = -1
zk_open_file_descriptor_count = -1
zk_max_file_descriptor_count = -1
zk_fsync_threshold_exceed_count	= -1
ok_cmd = ["""echo ruok | nc -q 3 localhost 2181"""]
mon_cmd = ["""echo mntr | nc -q 3 localhost 2181"""]

def collectMetrics():
    global collect_metrics
    global count

    collect_metrics = collect_metrics + "avg_latency=" + str(zk_avg_latency) + " max_latency=" + str(zk_max_latency) + " min_latancy=" + str(zk_min_latency)
    collect_metrics = collect_metrics + " packets_received=" + str(zk_packets_received) + " packets_sent=" + str(zk_packets_sent) + " num_alive_connections=" + str(zk_num_alive_connections)
    collect_metrics = collect_metrics + " outstanding_requests=" + str(zk_outstanding_requests) + " node_count=" + str(zk_znode_count) + " watch_count=" + str(zk_watch_count)
    collect_metrics = collect_metrics + " ephemerals_count=" + str(zk_ephemerals_count) + " approximate_data_size=" + str(zk_approximate_data_size)
    collect_metrics = collect_metrics + " open_file_descriptor_count=" + str(zk_open_file_descriptor_count) + " max_file_descriptor_count=" + str(zk_max_file_descriptor_count)
    collect_metrics = collect_metrics + " fsync_threshold_exceed_count=" + str(zk_fsync_threshold_exceed_count) + " collect_metrics_count=" + str(count)

while (return_value > 2):
    count += 1
    try:
        result = subprocess.check_output(ok_cmd,shell=True).decode("utf-8")
    except subprocess.CalledProcessError as e:
        print(f"UNKOWN: Command failed with return code {e.returncode}")
        sys.exit(3)
    if (result == "imok"):
        return_value = 0
        break
    if count > 5:
        return_value = 1
    #print(count)

if (result == "imok"):
    return_message = "OK"
else:
    return_value = 2
    #collectMetrics()
    #return_message = "CRITICAL Zookeeper did not answer ruok" + collect_metrics
    #print(return_message)
count = 0
while (count < 7):
    count += 1
    #print (count)
    try:
        metrics = subprocess.check_output(mon_cmd, shell=True).decode("utf-8")
    except subprocess.CalledProcessError as e:
        print(f"UNKOWN: Command failed with return code {e.returncode}")
        sys.exit(3)
    metrics_a = metrics.split('\n')
    for x in metrics_a:
        try:
            metric = x.split('\t')
            if (metric[0] == "zk_avg_latency"):
                zk_avg_latency = metric[1]
            if (metric[0] == "zk_max_latency"):
                zk_max_latency = metric[1]
            if (metric[0] == "zk_min_latency"):
                zk_min_latency = metric[1]
            if (metric[0] == "zk_packets_received"):
                zk_packets_received = metric[1]
            if (metric[0] == "zk_packets_sent"):
                zk_packets_sent = metric[1]
            if (metric[0] == "zk_num_alive_connections"):
                zk_num_alive_connections = metric[1]
            if (metric[0] == "zk_version"):
                zk_version = metric[1]
            if (metric[0] == "zk_server_state"):
                zk_server_state = metric[1]
            if (metric[0] == "zk_outstanding_requests"):
                zk_outstanding_requests = metric[1]
            if (metric[0] == "zk_znode_count"):
                zk_znode_count = metric[1]
            if (metric[0] == "zk_watch_count"):
                zk_watch_count = metric[1]
            if (metric[0] == "zk_ephemerals_count"):
                zk_ephemerals_count = metric[1]
            if (metric[0] == "zk_approximate_data_size"):
                zk_approximate_data_size = metric[1]
            if (metric[0] == "zk_open_file_descriptor_count"):
                zk_open_file_descriptor_count = metric[1]
            if (metric[0] == "zk_max_file_descriptor_count"):
                zk_max_file_descriptor_count = metric[1]
            if (metric[0] == "zk_fsync_threshold_exceed_count"):
                zk_fsync_threshold_exceed_count = metric[1]
        except:
            break
    if (int(zk_avg_latency) > -1):
        break
collectMetrics()
if (return_value < 2):
    return_message = "OK Zookeeper (" + zk_server_state + ") " + zk_version + collect_metrics
else:
    return_message = "CRITICAL Zookeeper did not answer ruok" + collect_metrics
print(return_message)
sys.exit(return_value)
